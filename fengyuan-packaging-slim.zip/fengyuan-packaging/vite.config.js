import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: '/fengyuan-packaging/',
  server: {
    host: '127.0.0.1'
  }
});
