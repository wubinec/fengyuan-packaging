import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Clock, 
  Layers, 
  Send, 
  CheckCircle2, 
  ChevronRight, 
  Sliders, 
  Box, 
  Award, 
  Globe2, 
  ArrowUpRight,
  Phone,
  Mail,
  MapPin,
  Check,
  PackageCheck,
  Languages,
  ChevronDown
} from 'lucide-react';
import { translations } from './translations';

export default function App() {
  // Supported languages
  const languageOptions = [
    { code: 'en', label: 'English', flag: '🇺🇸', name: 'EN' },
    { code: 'zh', label: '中文 (简体)', flag: '🇨🇳', name: '中' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪', name: 'DE' },
    { code: 'fr', label: 'Français', flag: '🇫🇷', name: 'FR' },
    { code: 'es', label: 'Español', flag: '🇪🇸', name: 'ES' },
    { code: 'ar', label: 'العربية (Arabic)', flag: '🇦🇪', name: 'AR' },
    { code: 'ru', label: 'Русский', flag: '🇷🇺', name: 'RU' },
    { code: 'ja', label: '日本語', flag: '🇯🇵', name: 'JA' }
  ];

  // Language State: default 'en'
  const [lang, setLang] = useState('en');
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  // Configurator state for interactive quote builder
  const [boxType, setBoxType] = useState('single-watch');
  const [material, setMaterial] = useState('lacquer-wood');
  const [lining, setLining] = useState('leather');
  const [branding, setBranding] = useState('foil');
  const [quantity, setQuantity] = useState(500);

  // Filter state for catalog
  const [catalogFilter, setCatalogFilter] = useState('all');

  // Contact / RFQ state
  const [rfqSubmitted, setRfqSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    requirements: '',
    quantity: '500-1000'
  });

  // Current translation dictionary
  const t = translations[lang] || translations.en;
  const isRtl = lang === 'ar';

  // Calculate estimated FOB price based on user custom configuration
  const calculateEstimate = () => {
    let base = 4.5;
    if (material === 'lacquer-wood') base += 5.5;
    if (material === 'hardwood-cherry') base += 3.2;
    if (material === 'pu-leather') base += 2.0;
    if (material === 'rigid-board') base += 1.0;

    if (lining === 'leather') base += 1.5;
    if (lining === 'velvet') base += 1.0;
    if (lining === 'eva') base += 0.8;

    if (branding === 'metal-plate') base += 1.2;
    if (branding === 'foil') base += 0.5;

    // Quantity tier discount
    let discount = 1.0;
    if (quantity >= 2000) discount = 0.75;
    else if (quantity >= 1000) discount = 0.85;
    else if (quantity >= 500) discount = 0.95;

    const unitPrice = (base * discount).toFixed(2);
    const totalPrice = (unitPrice * quantity).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    return { unitPrice, totalPrice };
  };

  const estimate = calculateEstimate();

  const getProductTitle = (id) => {
    const titles = {
      'FY-W22': {
        en: 'Heritage Lacquered Cherry Wood Watch Box',
        zh: '复古亮光樱桃木纹翻盖表盒',
        de: 'Klassische Uhrenschatulle Kirschholzoptik',
        fr: 'Écrin Montre en Bois Laqué Finition Merisier',
        es: 'Estuche de Reloj en Madera Acabado Cerezo',
        ar: 'علبة ساعة كلاسيكية خشب كرزي مطلي',
        ru: 'Классический футляр под вишневое дерево',
        ja: 'チェリーウッド調クラシック木製時計ケース'
      },
      'FY-W54': {
        en: 'Obsidian High-Gloss Piano Lacquer Watch Case',
        zh: '曜石黑高光钢琴漆单只腕表盒',
        de: 'Obsidian Klavierlack-Uhrenetui Hochglanz',
        fr: 'Coffret Montre Individuel Laque Noire Miroir',
        es: 'Estuche Individual Laca Piano Negro Obsidiana',
        ar: 'علبة ساعة فاخرة بطلاء بيانو أسود ملكي',
        ru: 'Элитный футляр черный рояльный лак',
        ja: '黒曜石ピアノ鏡面塗装プレミアムシングル時計箱'
      },
      'FY-S56': {
        en: 'Grand Horology Collector Presentation Suite',
        zh: '豪华腕表典藏全套礼盒套组',
        de: 'Exklusives Uhren-Präsentations-Gesamtset',
        fr: 'Suite Complète de Présentation Horlogère',
        es: 'Set Completo Exclusivo de Presentación Horológica',
        ar: 'طقم إهداء متكامل فاخر لجامعي الساعات',
        ru: 'Полный коллекционный презентационный сет',
        ja: '高級時計コレクター向けプレゼンテーション組箱'
      },
      'FY-C01': {
        en: 'Bespoke Executive Hardwood Gift Vault',
        zh: '高级定制实木烤漆多功能收纳盒',
        de: 'Maßgefertigte Hartholz-Geschenkschatulle',
        fr: 'Coffret Cadeau Prestige en Bois Massif Laqué',
        es: 'Cofre Ejecutivo a Medida en Madera Noble',
        ar: 'صندوق هدايا تنفيذي فاخر خشب مصمت مخصص',
        ru: 'Эксклюзивная шкатулка из массива дерева на заказ',
        ja: '特注エグゼクティブ無垢木製ギフトボックス'
      }
    };
    return titles[id]?.[lang] || titles[id]?.en;
  };

  const products = [
    {
      id: 'FY-W22',
      title: getProductTitle('FY-W22'),
      category: 'lacquer-wood',
      image: 'https://sc02.alicdn.com/kf/H7099277fee27456c91369ab63dbe5474I.png',
      moq: '200 pcs',
      fobRange: '$3.80 – $5.80',
      exFactoryRef: '¥22 Base',
      features: [
        t.retouchedNotice,
        lang === 'zh' ? '复古纯铜扣锁与合页' : 'Brass Hardware Clasp & Hinges',
        lang === 'zh' ? '仿皮纹质感表枕内衬' : 'Microfiber Cushion Lining',
        lang === 'zh' ? '精细倒角木工工艺' : 'Precision Beveled Mitering'
      ]
    },
    {
      id: 'FY-W54',
      title: getProductTitle('FY-W54'),
      category: 'piano-lacquer',
      image: 'https://sc02.alicdn.com/kf/H1c3ce30c8f124839a9fa5c27901a3e34J.png',
      moq: '200 pcs',
      fobRange: '$9.50 – $14.50',
      exFactoryRef: '¥54 Base',
      features: [
        t.retouchedNotice,
        lang === 'zh' ? '银色弹簧按压锁扣' : 'Polished Silver Push Latch',
        lang === 'zh' ? '米白皮纹内衬与表枕' : 'Cream Grain Leather Interior',
        lang === 'zh' ? '单只腕表典藏收纳' : 'Single Watch Display Vault'
      ]
    },
    {
      id: 'FY-S56',
      title: getProductTitle('FY-S56'),
      category: 'luxury-suite',
      image: 'https://sc02.alicdn.com/kf/Hda0f384bfcd6425f95db01f27ed3d1a49.png',
      moq: '200 pcs',
      fobRange: '$9.80 – $15.00',
      exFactoryRef: '¥56 Base',
      features: [
        t.retouchedNotice,
        lang === 'zh' ? '证书保修卡插袋全配' : 'Certificate Wallets & Inserts',
        lang === 'zh' ? '独立烤漆内盒' : 'Lacquered Inner Vault',
        lang === 'zh' ? '超纤柔软防刮表枕' : 'Microfiber Protective Pillow'
      ]
    },
    {
      id: 'FY-C01',
      title: getProductTitle('FY-C01'),
      category: 'lacquer-wood',
      image: 'https://sc02.alicdn.com/kf/H7a9a838bfc004ab5b1c16029cdf0a285V.png',
      moq: '300 pcs',
      fobRange: '$8.50 – $13.00',
      exFactoryRef: 'Custom ODM',
      features: [
        t.retouchedNotice,
        lang === 'zh' ? '配套专属定制封套纸盒' : 'Custom Outer Rigid Sleeve',
        lang === 'zh' ? '麂皮绒防磨内部凹槽' : 'Ultra-Suede Recessed Bed',
        lang === 'zh' ? '支持激光雕刻与烫金' : 'Laser Engraving & Stamping Ready'
      ]
    }
  ];

  const filteredProducts = catalogFilter === 'all' 
    ? products 
    : products.filter(p => p.category === catalogFilter);

  const handleRfqSubmit = (e) => {
    e.preventDefault();
    setRfqSubmitted(true);
    const subject = encodeURIComponent(`[RFQ Inquiry] ${formData.company || formData.name} - Custom Packaging Project`);
    const body = encodeURIComponent(
      `Dear Luke Wu / FY-Packaging Sales Team,\n\n` +
      `I would like to request an official quotation with the following project parameters:\n\n` +
      `• Contact Name: ${formData.name}\n` +
      `• Email: ${formData.email}\n` +
      `• Company / Brand: ${formData.company || 'Not Specified'}\n` +
      `• Estimated Order Tier: ${formData.quantity} pcs\n` +
      `• Selected Architecture: ${boxType}\n` +
      `• Material Selection: ${material}\n` +
      `• Inner Lining: ${lining}\n` +
      `• Branding Finish: ${branding}\n` +
      `• Target Volume: ${quantity} pcs\n` +
      `• Estimated FOB Target: $${estimate.unitPrice} / pc (Total: $${estimate.totalPrice})\n` +
      `• Detailed Requirements: ${formData.requirements || 'N/A'}\n\n` +
      `Please provide formal FOB quotation, sample lead time, and technical dieline.\n\n` +
      `Best regards,\n${formData.name}`
    );
    window.location.href = `mailto:13420913206@163.com?subject=${subject}&body=${body}`;
  };

  const currentLangObj = languageOptions.find(o => o.code === lang) || languageOptions[0];

  return (
    <div className={`min-h-screen bg-[#0D1117] text-[#F8F9FA] selection:bg-[#C5A059] selection:text-[#0D1117] ${isRtl ? 'rtl' : 'ltr'}`} dir={isRtl ? 'rtl' : 'ltr'}>
      {/* 1. Header & Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0D1117]/95 backdrop-blur-md border-b border-[#C5A059]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 border border-[#C5A059] flex items-center justify-center font-serif text-[#C5A059] text-xl font-bold tracking-wider">
              FY
            </div>
            <div>
              <div className="font-serif text-lg tracking-widest text-[#F8F9FA] font-medium">FY-PACKAGING</div>
              <div className="text-[10px] tracking-widest text-[#C5A059] uppercase">{t.brandSub}</div>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-6 text-xs uppercase tracking-wider text-[#A3B1C2]">
            <a href="#custom-builder" className="hover:text-[#C5A059] transition-colors">{t.navCustom}</a>
            <a href="#catalog" className="hover:text-[#C5A059] transition-colors">{t.navCatalog}</a>
            <a href="#craftsmanship" className="hover:text-[#C5A059] transition-colors">{t.navCraft}</a>
            <a href="#factory" className="hover:text-[#C5A059] transition-colors">{t.navFactory}</a>
          </nav>

          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Global Multi-Language Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center space-x-1.5 px-3 py-1.5 border border-[#C5A059]/30 text-xs text-[#DFC48D] hover:border-[#C5A059] bg-[#141A23] transition-all"
                title="Select Language / 多语言切换"
              >
                <Globe2 className="w-3.5 h-3.5 text-[#C5A059]" />
                <span className="text-sm">{currentLangObj.flag}</span>
                <span className="font-medium hidden sm:inline">{currentLangObj.name}</span>
                <ChevronDown className={`w-3 h-3 text-[#A3B1C2] transition-transform ${langDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-[#141A23] border border-[#C5A059]/40 shadow-2xl py-1 z-50 text-xs">
                  <div className="px-3 py-1.5 text-[10px] text-[#C5A059] uppercase font-mono tracking-wider border-b border-[#C5A059]/20">
                    Target Export Markets
                  </div>
                  {languageOptions.map(opt => (
                    <button
                      key={opt.code}
                      onClick={() => {
                        setLang(opt.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-[#C5A059]/15 transition-colors ${
                        lang === opt.code ? 'text-[#C5A059] font-semibold bg-[#C5A059]/10' : 'text-[#F8F9FA]'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <span className="text-base">{opt.flag}</span>
                        <span>{opt.label}</span>
                      </div>
                      {lang === opt.code && <Check className="w-3.5 h-3.5 text-[#C5A059]" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <a 
              href="#rfq" 
              className="inline-flex items-center px-3 sm:px-4 py-2 bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-widest hover:bg-[#DFC48D] transition-colors"
            >
              <span>{t.requestQuote}</span>
              <ArrowUpRight className="ml-1 w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </header>

      {/* 2. Hero Section */}
      <section className="relative pt-24 pb-20 md:pt-32 md:pb-32 overflow-hidden border-b border-[#C5A059]/15">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C5A059_1px,transparent_1px)] [background-size:24px_24px]"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#141A23] border border-[#C5A059]/30 text-[#C5A059] text-xs tracking-widest uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t.heroBadge}</span>
              </div>

              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-[#F8F9FA] leading-[1.18]">
                {t.heroTitle1} <br />
                <span className="luxury-gradient-text italic font-serif">{t.heroTitle2}</span> {t.heroTitle3}
              </h1>

              <p className="text-sm sm:text-base text-[#A3B1C2] max-w-2xl font-light leading-relaxed">
                {t.heroDesc}
              </p>

              <div className="pt-4 flex flex-wrap gap-4 items-center">
                <a 
                  href="#custom-builder"
                  className="px-6 py-3.5 bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-widest hover:bg-[#DFC48D] transition-all flex items-center space-x-2"
                >
                  <Sliders className="w-4 h-4" />
                  <span>{t.btnInteractive}</span>
                </a>
                <a 
                  href="#catalog"
                  className="px-6 py-3.5 bg-[#141A23] border border-[#C5A059]/40 text-[#F8F9FA] text-xs font-semibold uppercase tracking-widest hover:border-[#C5A059] transition-all flex items-center space-x-2"
                >
                  <Box className="w-4 h-4" />
                  <span>{t.btnCatalog}</span>
                </a>
              </div>

              {/* Verified Trust Badges */}
              <div className="pt-8 grid grid-cols-3 gap-6 border-t border-[#C5A059]/20 text-xs">
                <div>
                  <div className="font-serif text-xl text-[#C5A059] font-medium">{t.stat1Val}</div>
                  <div className="text-[#A3B1C2] mt-1">{t.stat1Lbl}</div>
                </div>
                <div>
                  <div className="font-serif text-xl text-[#C5A059] font-medium">{t.stat2Val}</div>
                  <div className="text-[#A3B1C2] mt-1">{t.stat2Lbl}</div>
                </div>
                <div>
                  <div className="font-serif text-xl text-[#C5A059] font-medium">{t.stat3Val}</div>
                  <div className="text-[#A3B1C2] mt-1">{t.stat3Lbl}</div>
                </div>
              </div>
            </div>

            {/* Hero Showcase Card */}
            <div className="lg:col-span-5">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-[#C5A059]/20 to-[#9A7B39]/20 blur-xl opacity-50 group-hover:opacity-75 transition-opacity"></div>
                <div className="relative bg-[#141A23] border border-[#C5A059]/40 p-4 sm:p-6 overflow-hidden">
                  <div className="aspect-[4/3] overflow-hidden bg-[#0D1117] relative">
                    <img 
                      src="https://sc02.alicdn.com/kf/H1c3ce30c8f124839a9fa5c27901a3e34J.png" 
                      alt="Luxury Watch Box Hero" 
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute top-3 left-3 bg-[#0D1117]/90 border border-[#C5A059]/30 text-[#C5A059] text-[10px] tracking-widest uppercase px-2.5 py-1 font-mono">
                      {t.heroCardTag}
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-between text-xs">
                    <div>
                      <div className="text-[#A3B1C2]">{t.heroCardPriceLbl}</div>
                      <div className="font-serif text-lg text-[#C5A059] font-medium">$9.50 – $14.50 <span className="text-xs text-[#A3B1C2]">/ pc</span></div>
                    </div>
                    <a 
                      href="#custom-builder"
                      className="px-4 py-2 bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/30 hover:bg-[#C5A059] hover:text-[#0D1117] transition-all text-xs uppercase tracking-wider"
                    >
                      {t.configure}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Interactive Custom Box Configurator */}
      <section id="custom-builder" className="py-20 md:py-28 bg-[#10151E] border-b border-[#C5A059]/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono mb-2">{t.configSub}</div>
            <h2 className="font-serif text-3xl sm:text-4xl text-white">{t.configTitle}</h2>
            <p className="text-xs sm:text-sm text-[#A3B1C2] mt-3">
              {t.configDesc}
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-start">
            {/* Step Controls */}
            <div className="lg:col-span-8 space-y-8 bg-[#141A23] p-6 sm:p-8 border border-[#C5A059]/20">
              {/* Step 1: Box Style */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step1}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  {[
                    { id: 'single-watch', label: lang === 'zh' ? '单只装腕表盒' : 'Single Watch Box', note: lang === 'zh' ? '经典主流款式' : 'Standard / Luxury' },
                    { id: 'dual-watch', label: lang === 'zh' ? '双表位对表盒' : 'Dual Watch Case', note: lang === 'zh' ? '收藏对表礼盒' : 'Collector Edition' },
                    { id: 'jewelry-vault', label: lang === 'zh' ? '首饰/珠宝戒指盒' : 'Jewelry / Ring Box', note: lang === 'zh' ? '翻盖精密五金' : 'Hinged Keepsake' },
                    { id: 'full-suite', label: lang === 'zh' ? '豪华全套包装组' : 'Full Luxury Suite', note: lang === 'zh' ? '外硬盒+内盒+卡槽' : 'Inner Box + Outer Sleeve' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setBoxType(item.id)}
                      className={`p-3 text-left border transition-all ${
                        boxType === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.note}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Outer Material */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step2}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  {[
                    { id: 'lacquer-wood', label: lang === 'zh' ? '镜面钢琴烤漆' : 'Piano Lacquer Wood', desc: lang === 'zh' ? '多层手工抛光' : 'Mirror Gloss Coating' },
                    { id: 'hardwood-cherry', label: lang === 'zh' ? '亮光樱桃木纹' : 'Cherry Stained Wood', desc: lang === 'zh' ? '天然木纹清漆' : 'Natural Grain Lacquer' },
                    { id: 'pu-leather', label: lang === 'zh' ? '高档十字纹PU皮' : 'Premium Saffiano PU', desc: lang === 'zh' ? '耐磨防刮质感' : 'Scratch-Proof Leatherette' },
                    { id: 'rigid-board', label: lang === 'zh' ? '触感特种艺术纸' : 'Touch Special Paper', desc: lang === 'zh' ? '轻奢高性价比' : 'Cost-Effective Luxury' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setMaterial(item.id)}
                      className={`p-3 text-left border transition-all ${
                        material === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Interior Insert & Lining */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step3}
                </label>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  {[
                    { id: 'leather', label: lang === 'zh' ? '荔枝纹细腻仿皮' : 'Grain Microfiber PU', desc: lang === 'zh' ? '防刮耐压柔韧' : 'Supple & Durable' },
                    { id: 'velvet', label: lang === 'zh' ? '高密柔顺天鹅绒' : 'High-Density Velvet', desc: lang === 'zh' ? '典雅珠宝保护' : 'Plush Jewel Protection' },
                    { id: 'eva', label: lang === 'zh' ? '高弹EVA精雕内托' : 'Recessed High-Resil EVA', desc: lang === 'zh' ? '定制精密贴合' : 'Custom Die-Cut' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setLining(item.id)}
                      className={`p-3 text-left border transition-all ${
                        lining === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 4: Branding Technique */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step4}
                </label>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  {[
                    { id: 'foil', label: lang === 'zh' ? '高温烫金 / 烫银' : 'Gold / Silver Foil Stamping', desc: lang === 'zh' ? '高清晰金属镜面' : 'Crisp Metallic Imprint' },
                    { id: 'metal-plate', label: lang === 'zh' ? '嵌入式纯铜/钢标牌' : 'Inlaid Brass / Steel Badge', desc: lang === 'zh' ? '厚重奢华立体标' : 'Solid Metal Emblem' },
                    { id: 'deboss', label: lang === 'zh' ? '微压凹立体压纹' : 'Precision Blind Deboss', desc: lang === 'zh' ? '低调高级触感' : 'Subtle Tactile Relief' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setBranding(item.id)}
                      className={`p-3 text-left border transition-all ${
                        branding === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 5: Quantity Slider */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
                    {t.step5}
                  </label>
                  <span className="font-mono text-sm text-[#C5A059] bg-[#0D1117] px-3 py-1 border border-[#C5A059]/30">
                    {quantity.toLocaleString()} pcs
                  </span>
                </div>
                <input 
                  type="range" 
                  min="200" 
                  max="5000" 
                  step="100"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full h-1.5 bg-[#0D1117] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
                />
                <div className="flex justify-between text-[10px] sm:text-[11px] text-[#A3B1C2] mt-1 font-mono">
                  <span>200 (Pilot)</span>
                  <span>500 (Standard)</span>
                  <span>1,000 (Bulk)</span>
                  <span>5,000+ (Full Container)</span>
                </div>
              </div>
            </div>

            {/* Instant Pricing & RFQ Summary Card */}
            <div className="lg:col-span-4 bg-[#141A23] border border-[#C5A059] p-6 sticky top-28 space-y-6">
              <div className="border-b border-[#C5A059]/20 pb-4">
                <div className="text-[11px] uppercase tracking-widest text-[#C5A059] font-mono">{t.quoteSub}</div>
                <div className="font-serif text-xl text-[#F8F9FA] mt-1">{t.quoteTitle}</div>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'zh' ? '定制盒型' : 'Style'}</span>
                  <span className="font-medium capitalize text-white">{boxType.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'zh' ? '外壳材质' : 'Exterior'}</span>
                  <span className="font-medium capitalize text-white">{material.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'zh' ? '内衬选择' : 'Lining'}</span>
                  <span className="font-medium capitalize text-white">{lining}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'zh' ? 'Logo工艺' : 'Branding'}</span>
                  <span className="font-medium capitalize text-white">{branding.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'zh' ? '采购批量' : 'Volume'}</span>
                  <span className="font-mono text-white">{quantity.toLocaleString()} pcs</span>
                </div>
              </div>

              {/* Price Calculation Output */}
              <div className="bg-[#0D1117] p-4 border border-[#C5A059]/30 text-center">
                <div className="text-[10px] uppercase tracking-widest text-[#A3B1C2]">{t.estFobUnit}</div>
                <div className="font-serif text-3xl text-[#C5A059] font-semibold mt-1">
                  ${estimate.unitPrice} <span className="text-xs font-normal text-[#A3B1C2]">/ pc</span>
                </div>
                <div className="text-xs text-[#A3B1C2] mt-2">
                  {t.totalVolumeFob} <span className="font-mono text-white font-medium">${estimate.totalPrice}</span>
                </div>
              </div>

              <div className="space-y-2 text-[11px] text-[#A3B1C2]">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>{t.freeDieline}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>{t.sampleTurnaround}</span>
                </div>
              </div>

              <a 
                href="#rfq"
                className="w-full py-3.5 bg-[#C5A059] text-[#0D1117] font-semibold uppercase tracking-widest text-xs hover:bg-[#DFC48D] transition-colors flex items-center justify-center space-x-2"
              >
                <span>{t.btnLockSpec}</span>
                <ChevronRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Product Catalog (Featured Collection) */}
      <section id="catalog" className="py-20 md:py-28 border-b border-[#C5A059]/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono mb-2">{t.catSub}</div>
              <h2 className="font-serif text-3xl sm:text-4xl text-white">{t.catTitle}</h2>
              <p className="text-xs sm:text-sm text-[#A3B1C2] mt-2 max-w-xl">
                {t.catDesc}
              </p>
            </div>

            {/* Category Filter Tabs */}
            <div className="mt-6 md:mt-0 flex flex-wrap gap-2 text-xs">
              {[
                { id: 'all', label: t.filterAll },
                { id: 'piano-lacquer', label: t.filterPiano },
                { id: 'lacquer-wood', label: t.filterWood },
                { id: 'luxury-suite', label: t.filterSuite }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setCatalogFilter(f.id)}
                  className={`px-4 py-2 text-xs uppercase tracking-wider transition-all border ${
                    catalogFilter === f.id
                      ? 'border-[#C5A059] bg-[#C5A059] text-[#0D1117] font-semibold'
                      : 'border-[#C5A059]/20 text-[#A3B1C2] hover:border-[#C5A059]/50'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Catalog Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map(product => (
              <div key={product.id} className="bg-[#141A23] border border-[#C5A059]/20 group hover:border-[#C5A059] transition-all">
                <div className="aspect-[4/3] bg-[#0D1117] overflow-hidden relative">
                  <img 
                    src={product.image} 
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                  />
                  <div className="absolute top-3 left-3 bg-[#0D1117]/90 px-2.5 py-1 text-[10px] font-mono text-[#C5A059] border border-[#C5A059]/30">
                    {product.id}
                  </div>
                  <div className="absolute bottom-3 right-3 bg-[#0D1117]/90 px-2.5 py-1 text-[10px] font-mono text-[#A3B1C2] border border-[#C5A059]/20">
                    MOQ: {product.moq}
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <h3 className="font-serif text-lg text-white font-normal line-clamp-1 group-hover:text-[#C5A059] transition-colors">
                    {product.title}
                  </h3>

                  <div className="flex justify-between items-baseline py-2 border-y border-[#C5A059]/10 text-xs">
                    <span className="text-[#A3B1C2]">{t.fobPriceRange}</span>
                    <span className="font-serif text-base text-[#C5A059] font-medium">{product.fobRange}</span>
                  </div>

                  <ul className="space-y-1.5 text-xs text-[#A3B1C2]">
                    {product.features.map((feat, idx) => (
                      <li key={idx} className="flex items-center space-x-2">
                        <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                        <span className="truncate">{feat}</span>
                      </li>
                    ))}
                  </ul>

                  <a 
                    href="#rfq"
                    className="block w-full text-center py-2.5 border border-[#C5A059]/30 text-[#C5A059] text-xs uppercase tracking-wider hover:bg-[#C5A059] hover:text-[#0D1117] transition-all font-semibold"
                  >
                    {t.inquireItem}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Craftsmanship & Finishing Capabilities */}
      <section id="craftsmanship" className="py-20 md:py-28 bg-[#10151E] border-b border-[#C5A059]/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono mb-2">{t.craftSub}</div>
            <h2 className="font-serif text-3xl sm:text-4xl text-white">{t.craftTitle}</h2>
            <p className="text-xs sm:text-sm text-[#A3B1C2] mt-3">
              {t.craftDesc}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: t.craft1Title,
                desc: t.craft1Desc,
                icon: Sparkles
              },
              {
                title: t.craft2Title,
                desc: t.craft2Desc,
                icon: Layers
              },
              {
                title: t.craft3Title,
                desc: t.craft3Desc,
                icon: ShieldCheck
              },
              {
                title: t.craft4Title,
                desc: t.craft4Desc,
                icon: Clock
              }
            ].map((cap, i) => (
              <div key={i} className="bg-[#141A23] border border-[#C5A059]/20 p-6 space-y-3 hover:border-[#C5A059]/50 transition-colors">
                <cap.icon className="w-6 h-6 text-[#C5A059]" />
                <h3 className="font-serif text-base text-white font-medium">{cap.title}</h3>
                <p className="text-xs text-[#A3B1C2] leading-relaxed font-light">{cap.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Factory Credibility & Facility */}
      <section id="factory" className="py-20 md:py-28 border-b border-[#C5A059]/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono">{t.factSub}</div>
              <h2 className="font-serif text-3xl sm:text-4xl text-white leading-tight">
                {t.factTitle}
              </h2>
              <p className="text-sm text-[#A3B1C2] leading-relaxed">
                {t.factDesc}
              </p>

              <div className="space-y-3 text-xs text-[#F8F9FA] pt-2">
                <div className="flex items-start space-x-3">
                  <Award className="w-4 h-4 text-[#C5A059] mt-0.5 shrink-0" />
                  <span>{t.factPoint1}</span>
                </div>
                <div className="flex items-start space-x-3">
                  <ShieldCheck className="w-4 h-4 text-[#C5A059] mt-0.5 shrink-0" />
                  <span>{t.factPoint2}</span>
                </div>
                <div className="flex items-start space-x-3">
                  <Globe2 className="w-4 h-4 text-[#C5A059] mt-0.5 shrink-0" />
                  <span>{t.factPoint3}</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 bg-[#141A23] border border-[#C5A059]/30 p-6 space-y-4 text-xs">
              <div className="font-serif text-lg text-white font-medium border-b border-[#C5A059]/20 pb-3">
                {t.factDirectTitle}
              </div>
              <div className="space-y-3 text-[#A3B1C2]">
                <div>
                  <div className="text-[#C5A059] uppercase font-mono text-[10px]">{t.factLoc}</div>
                  <div className="text-white mt-0.5 font-sans">{t.factLocVal}</div>
                </div>
                <div>
                  <div className="text-[#C5A059] uppercase font-mono text-[10px]">{t.factEst}</div>
                  <div className="text-white mt-0.5">{t.factEstVal}</div>
                </div>
                <div>
                  <div className="text-[#C5A059] uppercase font-mono text-[10px]">{t.factCore}</div>
                  <div className="text-white mt-0.5">{t.factCoreVal}</div>
                </div>
                <div>
                  <div className="text-[#C5A059] uppercase font-mono text-[10px]">{t.factPort}</div>
                  <div className="text-white mt-0.5">{t.factPortVal}</div>
                </div>
              </div>
              <div className="p-3 bg-[#0D1117] border border-[#C5A059]/20 text-[11px] text-[#A3B1C2] leading-normal">
                {t.factBuyerNote}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. RFQ Inquiry Form */}
      <section id="rfq" className="py-20 md:py-28 bg-[#10151E] border-b border-[#C5A059]/15">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#141A23] border border-[#C5A059]/30 p-8 sm:p-12">
            <div className="text-center max-w-xl mx-auto mb-8">
              <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono mb-2">{t.rfqSub}</div>
              <h2 className="font-serif text-3xl text-white">{t.rfqTitle}</h2>
              <p className="text-xs text-[#A3B1C2] mt-2">
                {t.rfqDesc}
              </p>

              {/* Direct Fast Contact Badges */}
              <div className="mt-6 flex flex-wrap justify-center gap-4 text-xs">
                <a 
                  href="https://wa.me/8613420913206?text=Hello%20Luke%20Wu,%20I%20am%20interested%20in%20custom%20watch%20boxes%20from%20FY-Packaging." 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-[#25D366]/10 border border-[#25D366]/40 text-[#25D366] hover:bg-[#25D366]/20 transition-all font-mono"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>WhatsApp: +86 13420913206 (Luke Wu)</span>
                </a>
                <a 
                  href="mailto:13420913206@163.com?subject=Custom%20Packaging%20Inquiry%20from%20FY-Pack" 
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-[#C5A059]/10 border border-[#C5A059]/40 text-[#DFC48D] hover:bg-[#C5A059]/20 transition-all font-mono"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email: 13420913206@163.com</span>
                </a>
              </div>
            </div>

            {rfqSubmitted ? (
              <div className="bg-[#0D1117] border border-[#C5A059] p-8 text-center space-y-4">
                <div className="w-16 h-16 bg-[#C5A059]/20 text-[#C5A059] mx-auto flex items-center justify-center rounded-full">
                  <PackageCheck className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl text-white">{t.rfqSuccessTitle}</h3>
                <p className="text-xs text-[#A3B1C2] max-w-md mx-auto">
                  {t.rfqSuccessDesc}
                </p>
                <div className="pt-4">
                  <button
                    onClick={() => setRfqSubmitted(false)}
                    className="px-6 py-2.5 bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-wider hover:bg-[#DFC48D]"
                  >
                    {t.rfqAnother}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleRfqSubmit} className="space-y-6 text-xs">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[#A3B1C2] mb-2">{t.lblYourName}</label>
                    <input 
                      type="text" 
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g., Alexander Wright"
                      className="w-full bg-[#0D1117] border border-[#C5A059]/20 p-3.5 text-white focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[#A3B1C2] mb-2">{t.lblEmail}</label>
                    <input 
                      type="email" 
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="alexander@horologybrand.com"
                      className="w-full bg-[#0D1117] border border-[#C5A059]/20 p-3.5 text-white focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[#A3B1C2] mb-2">{t.lblCompany}</label>
                    <input 
                      type="text" 
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      placeholder="Geneva Watch Co. / Luxury Boutique"
                      className="w-full bg-[#0D1117] border border-[#C5A059]/20 p-3.5 text-white focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[#A3B1C2] mb-2">{t.lblQuantity}</label>
                    <select 
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                      className="w-full bg-[#0D1117] border border-[#C5A059]/20 p-3.5 text-white focus:border-[#C5A059] focus:outline-none"
                    >
                      <option value="200-500">200 – 500 pcs (Sampling / Pilot)</option>
                      <option value="500-1000">500 – 1,000 pcs (Standard Bulk)</option>
                      <option value="1000-3000">1,000 – 3,000 pcs (Volume Tier)</option>
                      <option value="3000+">3,000+ pcs (Container Program)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[#A3B1C2] mb-2">{t.lblReq}</label>
                  <textarea 
                    rows={4}
                    value={formData.requirements}
                    onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                    placeholder="Enter interior cushion size, lacquer color preference, foil stamping dimensions, or outer sleeve requirements..."
                    className="w-full bg-[#0D1117] border border-[#C5A059]/20 p-3.5 text-white focus:border-[#C5A059] focus:outline-none"
                  ></textarea>
                </div>

                <div className="pt-2">
                  <button 
                    type="submit"
                    className="w-full py-4 bg-[#C5A059] text-[#0D1117] font-semibold uppercase tracking-widest text-xs hover:bg-[#DFC48D] transition-colors flex items-center justify-center space-x-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{t.btnSendRfq}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* 8. Footer */}
      <footer className="py-12 bg-[#0D1117] border-t border-[#C5A059]/15 text-xs text-[#A3B1C2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-3">
            <div className="font-serif text-lg text-white font-semibold">FY-PACKAGING</div>
            <p className="text-[11px] leading-relaxed">
              Guangzhou Fengyuan Craft Products Co., Ltd.<br />
              Specialized manufacturer of bespoke luxury watch packaging and presentation craft boxes.
            </p>
          </div>

          <div>
            <div className="text-white font-semibold uppercase tracking-wider mb-3">Product Ranges</div>
            <ul className="space-y-1.5 text-[11px]">
              <li>Piano Lacquer Watch Cases</li>
              <li>Cherry Finish Wooden Boxes</li>
              <li>Jewelry & Keepsake Vaults</li>
              <li>Full Outer & Inner Packaging Suites</li>
            </ul>
          </div>

          <div>
            <div className="text-white font-semibold uppercase tracking-wider mb-3">Custom Services</div>
            <ul className="space-y-1.5 text-[11px]">
              <li>OEM / ODM Rapid Sampling</li>
              <li>Dieline & Vector Layout Support</li>
              <li>Laser Engraving & Hot Stamping</li>
              <li>Drop-Shipping Export Palletizing</li>
            </ul>
          </div>

          <div>
            <div className="text-white font-semibold uppercase tracking-wider mb-3">Direct Workshop & Contact</div>
            <p className="text-[11px] leading-relaxed">
              No. 14 Jinpen Middle Road, Zhongluotan Town, Baiyun District, Guangzhou, Guangdong, China.
            </p>
            <div className="mt-2 text-[11px] text-white">
              WhatsApp: <a href="https://wa.me/8613420913206" target="_blank" rel="noreferrer" className="text-[#C5A059] underline hover:text-[#DFC48D]">+86 13420913206 (Luke Wu)</a>
            </div>
            <div className="mt-1 text-[11px] text-white">
              Email: <a href="mailto:13420913206@163.com" className="text-[#C5A059] underline hover:text-[#DFC48D]">13420913206@163.com</a>
            </div>
            <div className="mt-2 text-[11px] text-[#A3B1C2]">
              Export Ports: Guangzhou / Shenzhen (FOB)
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-[#C5A059]/10 flex flex-col sm:flex-row justify-between items-center text-[10px] text-[#A3B1C2]">
          <div>© {new Date().getFullYear()} Guangzhou Fengyuan Craft Products Co., Ltd. All rights reserved.</div>
          <div className="mt-2 sm:mt-0 space-x-4">
            <span>Confidential OEM Protection Guaranteed</span>
            <span>•</span>
            <span>Worldwide Express Sampling</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
