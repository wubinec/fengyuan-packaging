---
version: alpha
name: Fengyuan Atelier
description: A dark gallery-and-ledger design system for Guangzhou Fengyuan Craft Products — custom watch, jewelry, lacquer and leather packaging made for international luxury brands.

colors:
  canvas: "#0D1117"
  canvas-deep: "#080B10"
  surface: "#131A21"
  surface-raised: "#1A222B"
  forest: "#0A2118"
  forest-deep: "#06150E"
  wood: "#1A0D08"
  wood-raised: "#261410"
  ivory: "#F8F9FA"
  ivory-deep: "#EDEAE3"
  ink: "#0D1117"
  ink-soft: "#4A5259"
  ink-muted: "#6B6F73"
  text-primary: "#F4F1EA"
  text-secondary: "#C2BBAE"
  text-muted: "#9A9384"
  gold: "#D4AF37"
  gold-deep: "#C5A059"
  gold-pale: "#E9D9A8"
  gold-press: "#B8952F"
  gold-ink: "#8A6B2A"
  gold-tint: "rgba(212, 175, 55, 0.14)"
  gold-hairline: "rgba(212, 175, 55, 0.35)"
  border-subtle: "rgba(244, 241, 234, 0.10)"
  border-strong: "rgba(244, 241, 234, 0.22)"
  border-ivory: "#DCD7CC"
  success: "#6FA97D"
  warning: "#D9A24B"
  danger: "#C86A5E"
  danger-ink: "#9C3B30"
  focus-ring: "#D4AF37"

typography:
  display-xl:
    fontFamily: "Bodoni Moda, Didot, Georgia, serif"
    fontSize: 76px
    fontWeight: 400
    lineHeight: 0.96
    letterSpacing: -0.025em
  display-lg:
    fontFamily: "Bodoni Moda, Didot, Georgia, serif"
    fontSize: 56px
    fontWeight: 400
    lineHeight: 1.02
    letterSpacing: -0.022em
  display-md:
    fontFamily: "Bodoni Moda, Didot, Georgia, serif"
    fontSize: 40px
    fontWeight: 400
    lineHeight: 1.08
    letterSpacing: -0.018em
  headline-sm:
    fontFamily: "Bodoni Moda, Didot, Georgia, serif"
    fontSize: 28px
    fontWeight: 500
    lineHeight: 1.2
    letterSpacing: -0.012em
  body-lg:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 1.65
    letterSpacing: 0
  body-md:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.65
    letterSpacing: 0
  body-sm:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.55
    letterSpacing: 0.005em
  caption:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 1.45
    letterSpacing: 0.01em
  label-caps:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 12px
    fontWeight: 600
    lineHeight: 1
    letterSpacing: 0.14em
  eyebrow:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 11px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: 0.16em
  nav-link:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1
    letterSpacing: 0.02em
  button:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 14px
    fontWeight: 600
    lineHeight: 1
    letterSpacing: 0.04em
  spec-value:
    fontFamily: "Archivo, Helvetica Neue, Arial, sans-serif"
    fontSize: 15px
    fontWeight: 500
    lineHeight: 1.2
    letterSpacing: 0.02em
    fontFeature: "tnum"

rounded:
  none: 0px
  sm: 2px
  md: 4px
  lg: 8px
  full: 9999px

spacing:
  base: 4px
  xxs: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
   xl: 32px
   xxl: 48px
   xxxl: 64px
   huge: 96px
   max: 128px
   gutter: 24px
  container-max: 1240px
  section-desktop: 128px
  section-tight: 96px
  section-tablet: 88px
  section-phone: 64px
  nav-height: 76px
  touch-target: 44px

components:
  nav-bar:
    backgroundColor: "{colors.canvas-deep}"
    textColor: "{colors.text-primary}"
    height: 76px
    padding: "{spacing.md}"
  nav-link:
    textColor: "{colors.text-secondary}"
    typography: "{typography.nav-link}"
    height: 44px
    padding: "{spacing.sm}"
  nav-link-active:
    textColor: "{colors.gold}"
    typography: "{typography.nav-link}"
  button-primary:
    backgroundColor: "{colors.gold}"
    textColor: "{colors.ink}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: 52px
    padding: "{spacing.lg}"
  button-primary-hover:
    backgroundColor: "{colors.gold-deep}"
    textColor: "{colors.ink}"
  button-primary-active:
    backgroundColor: "{colors.gold-press}"
    textColor: "{colors.ink}"
  button-secondary:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.text-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: 52px
    padding: "{spacing.lg}"
  button-secondary-hover:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.gold-pale}"
  button-ghost:
    backgroundColor: transparent
    textColor: "{colors.gold-deep}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: 44px
    padding: "{spacing.md}"
  spec-plate:
    backgroundColor: "{colors.ivory}"
    textColor: "{colors.ink}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
  input-field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-md}"
    rounded: "{rounded.sm}"
    height: 52px
    padding: "{spacing.md}"
  input-label:
    textColor: "{colors.text-secondary}"
    typography: "{typography.label-caps}"
  textarea-field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-md}"
    rounded: "{rounded.sm}"
    height: 148px
    padding: "{spacing.md}"
  select-field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-md}"
    rounded: "{rounded.sm}"
    height: 52px
    padding: "{spacing.md}"
  chip-filter:
    backgroundColor: transparent
    textColor: "{colors.text-secondary}"
    typography: "{typography.label-caps}"
    rounded: "{rounded.sm}"
    height: 44px
    padding: "{spacing.md}"
  chip-filter-selected:
    backgroundColor: "{colors.gold-tint}"
    textColor: "{colors.gold-pale}"
    typography: "{typography.label-caps}"
    rounded: "{rounded.sm}"
    height: 44px
    padding: "{spacing.md}"
  option-tile:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.sm}"
    height: 108px
    padding: "{spacing.md}"
  option-tile-selected:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.gold-pale}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.sm}"
    height: 108px
  step-marker:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.text-muted}"
    typography: "{typography.label-caps}"
    rounded: "{rounded.full}"
    size: 32px
  step-marker-active:
    backgroundColor: "{colors.gold}"
    textColor: "{colors.ink}"
    typography: "{typography.label-caps}"
    rounded: "{rounded.full}"
    size: 32px
  product-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "{spacing.lg}"
  craftsmanship-tile:
    backgroundColor: "{colors.wood}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "{spacing.lg}"
  metric-band:
    backgroundColor: "{colors.forest}"
    textColor: "{colors.text-primary}"
    typography: "{typography.display-md}"
    rounded: "{rounded.none}"
    padding: "{spacing.xxl}"
  quote-panel:
    backgroundColor: "{colors.ivory}"
    textColor: "{colors.ink}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
  quote-figure:
    textColor: "{colors.ink}"
    typography: "{typography.spec-value}"
  badge-verified:
    backgroundColor: "{colors.forest-deep}"
    textColor: "{colors.gold-pale}"
    typography: "{typography.eyebrow}"
    rounded: "{rounded.full}"
    height: 28px
    padding: "{spacing.sm}"
  file-dropzone:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text-muted}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    height: 148px
    padding: "{spacing.lg}"
  footer-band:
    backgroundColor: "{colors.canvas-deep}"
    textColor: "{colors.text-muted}"
    typography: "{typography.body-sm}"
    padding: "{spacing.xxxl}"
  footer-heading:
    textColor: "{colors.text-secondary}"
    typography: "{typography.label-caps}"
  inline-link:
    textColor: "{colors.gold-pale}"
    typography: "{typography.body-sm}"
---

# Fengyuan Atelier

## Overview

Guangzhou Fengyuan Craft Products has been making watch boxes, jewelry cases, lacquer and leather packaging for export since 2008. The website is not a marketplace listing; it is the digital equivalent of walking into a quiet workshop showroom where finished cases sit under focused light and every claim is stamped on a printed specification card. The visual system is called **Black Lacquer Gallery**: dark, matte, architectural surfaces carry the photography, while **pristine ivory specification plates** carry the facts a buyer must verify — sample lead time, MOQ, material, dimensions, QC.

The personality is *archival, precise, unhurried*. The audience is an overseas brand owner, watchmaker, or boutique buyer comparing a Guangzhou factory against a European converter; they are skeptical, they read specifications, and they decide on craft evidence. The interface must therefore feel expensive without decoration, and factual without feeling like an Alibaba storefront. Emotional target: **"this factory can hold our brand's standard."**

**The one bold move.** Every major band is a dark gallery wall; every proof point is an ivory placard pinned to it. Content alternates between obsidian gallery sections and ivory card clusters rather than stacking identical dark cards. Section eyebrows are preceded by a single 48px brass hairline — one per section, never more — so the page reads as a hung exhibition, not a template.

**The first viewport.** A 76px deep-obsidian navigation bar with a wordmark set in display serif and a single champagne-filled "Request a quote" button. Below it, an asymmetric 7/5 split: left, a small tracked eyebrow (`GUANGZHOU · EST. 2008 · OEM / ODM`), then a serif display headline of two or three lines at 76px on desktop — e.g. *"Cases built to outlive the object they hold."* — a lede set to a 62-character measure in warm off-white, and two actions: a solid champagne "Start a custom project" and a hairline-outlined "Explore in-stock catalog". Right, an ivory **specification plate** lifted slightly above the fold, containing three ledger rows separated by hairlines (Sampling `3–5 days`, MOQ `Low-to-medium, flexible`, Verified `Since 2008`), each label in 12px tracked caps and each value in tabular figures, closed by a quiet inline link to the factory profile. The hero photograph — real product photography of a lacquered case, lit warm from one side — is full-bleed behind or beside the composition at 40–55% coverage, never a CSS gradient standing in for an image. Depth comes from photography and tonal layering, never from a purple or blue "trust" gradient.

Restraint rules: no emoji, no generic three-equal-card rows, no lorem ipsum, no invented performance statistics. Numbers on the page come from verified facts (2008 origin, 12+ years, 3–5 day sampling, 100% pre-shipment QC) or are clearly labelled as estimates inside the configurator.

## Colors

The palette is 85% dark neutral, 8% ivory, 5% brass, 2% material color. It is drawn from the product itself: black piano lacquer, deep green velvet, dark walnut, brass hardware, and printer's ivory card stock.

- **Canvas (#0D1117) — obsidian.** The default page surface and the gallery wall. Never pure black; pure black kills the lacquer sheen in photography.
- **Canvas Deep (#080B10).** Navigation bar, footer band, and the recessed wells behind option tiles. One step below canvas so chrome separates without borders.
- **Surface (#131A21) / Surface Raised (#1A222B).** Product cards, form fields, and selected option states. These are *tonal* steps, barely 1.2:1 from canvas, so they always carry a hairline border.
- **Forest (#0A2118) / Forest Deep (#06150E).** Deep green velvet. Reserved for the factory-strength metric band and verification badges — the "inside of the box" moments. Never place forest directly against wood; separate them with canvas or ivory.
- **Wood (#1A0D08) / Wood Raised (#261410).** Warm dark walnut, used for craftsmanship and finish tiles where the subject is lacquer, leather, or wood grain. Wood bands get a 1px inset top highlight in `gold-hairline` to read as a lid edge.
- **Ivory (#F8F9FA) / Ivory Deep (#EDEAE3).** Pristine specification plates, quote panel, and the hero plate. Ivory is a *content* surface, not a background wash: it occupies at most one third of any viewport and always sits on canvas with a 1px `border-ivory` edge, no shadow.
- **Ink (#0D1117), Ink Soft (#4A5259), Ink Muted (#6B6F73).** All text inside ivory plates. Ink on ivory is 16:1; Ink Muted is 4.9:1 and is the lightest text permitted on ivory.
- **Gold (#D4AF37) — champagne.** The single accent. Fill for the one primary action per viewport, plus one state signal chosen from the active step marker, the active navigation item, or the brass section hairline. Gold on canvas is 9.7:1.
- **Gold Deep (#C5A059), Gold Pale (#E9D9A8), Gold Press (#B8952F).** Hover, high-legibility accent text on dark, and pressed states. Gold Pale is preferred over Gold for small text on wood or surface-raised.
- **Gold Ink (#8A6B2A).** The only gold permitted as text on ivory (4.7:1). Plain gold on ivory is 1.8:1 and is forbidden.
- **Border tokens.** `border-subtle` (10% warm white) for structure, `border-strong` (22%) for hover and focused containers, `gold-hairline` (35% gold) for the section rule and selected option outlines. Avoid solid dark borders on dark surfaces.
- **Semantic.** Success `#6FA97D`, Warning `#D9A24B`, Danger `#C86A5E`, plus `danger-ink` `#9C3B30` for errors inside ivory panels. Semantic color is never the only signal — pair it with an icon or a text label.

**Accent discipline.** At most two visible gold statements per screen region: typically one brass hairline plus one primary CTA, or one active nav item plus one selected state. The configurator communicates selection with a gold outlined tile and a check icon, not a solid gold block, so the CTA keeps its dominance. Text contrast must be at least 4.5:1 for normal text and 3:1 for large text and UI boundaries; never place body copy in `text-muted` on `surface`.

## Typography

Two families, strict roles. **Bodoni Moda** carries editorial authority — its high-contrast Didone strokes echo watch dials, hallmark engraving, and fashion-house print. **Archivo** carries every functional string: navigation, body, labels, specifications. No third family; technical metadata is set in Archivo at small sizes with wide tracking and tabular figures instead of a monospace face.

- **Display (Bodoni Moda 400/500).** Only at 28px and above. H1 uses `display-xl` (76px, 0.96 leading, -0.025em); section titles use `display-lg` or `display-md`; card titles use `headline-sm`. Headlines are left-aligned and set to 2–4 lines within an 18–24ch measure; never center a display headline over a photograph.
- **Body (Archivo 400).** `body-lg` 18px for hero ledes and section intros, `body-md` 16px for paragraphs and form values, `body-sm` 14px for card copy, table cells, and footer. Line length 50–75 characters (`max-width: 65ch`). Never justify text.
- **Labels (Archivo 600, caps).** `label-caps` 12px at 0.14em for eyebrows, field labels, filter chips, and specification keys; `eyebrow` 11px at 0.16em for the small line above a section title. Uppercase always carries at least 0.06em tracking — no exceptions.
- **Button text (Archivo 600, 14px).** Sentence case, 0.04em tracking, never uppercase.
- **Specification values (Archivo 500, 15px, tabular).** `spec-value` with `tnum` for dimensions (mm), quantities, sample days, and quote figures so columns of numbers align. Units sit in `caption` scale, not inline uppercase.

Weight discipline is three steps only: 400 read, 500/600 emphasize and announce. Do not build a 400→700 ladder. Above the fold, use no more than three type sizes (eyebrow, display, body-lg). Italic Bodoni is allowed for exactly one pull quote in the craftsmanship section and nowhere else. On phones, display sizes scale down to 44/36/28px with tracking eased to -0.015em; body never drops below 15px and labels never below 11px.

## Layout

A 1240px fixed-max container on a 12-column grid with 24px gutters; margins 40px desktop, 24px tablet, 20px phone. Sections use deliberately uneven vertical rhythm so spacing itself carries hierarchy: gallery sections 128px, supporting bands 96px, micro bands (filter row, trust strip) 64px, tablet 88px, phone 64px.

- **Hero.** 7/5 asymmetric split with the text column flush left and the ivory specification plate offset 32–48px below the top of the text block, so the plate overlaps the photography edge. The plate is never centered; its width is 360–420px on desktop.
- **Configurator.** 7/5 split: option steps in the wider left column, a sticky 360px ivory quote rail on the right that stays 96px below the navigation. Steps stack vertically as numbered rows on desktop, become a horizontally scrollable step strip on tablet, and collapse to an accordion with one open step on phone. A sticky progress label (`STEP 2 OF 5`) sits above the options.
- **Catalog.** Three identical cards in a row are banned. Use a featured tile spanning 2 columns (taller image, longer caption) followed by 2-up and 3-up cards, all on a 24px gutter; the filter chip row is a single horizontal line that scrolls on small screens.
- **Craftsmanship / factory.** A two-column editorial band: full-bleed image on one side, 6-column text block on the other, alternating sides between sections. Metric bands break the grid with full-width forest color and three to four figures separated by 1px hairline rules.
- **RFQ.** Two-column form: fields in 8 columns, contact methods (WhatsApp, email, WeChat work account) in a 4-column rail; on phone, the rail moves above the form and both buttons stay full width.

Breakpoints: 1440 (content cap), 1200, 1024 (grid drops to 8 columns, hero becomes stacked), 768 (single column, nav collapses to a menu sheet), 560 (phone spacing and type). All interactive targets are at least 44×44 CSS px with at least 8px between adjacent hit areas; icon-only controls get a 44px invisible hit box. Images use a 4:5 or 1:1 ratio inside cards and 16:9 or 3:2 for full-bleed bands; never crop a box so its lid and base are cut in half.

## Elevation & Depth

Depth is **tonal and photographic, never shadowed**. Six strata, in order: `canvas-deep` (chrome and wells) → `canvas` (page) → `surface` (cards, fields) → `surface-raised` (selected or hovered tiles) → `wood`/`forest` (material bands) → `ivory` (plates). Each step is paired with a 1px `border-subtle` hairline, because the tonal difference alone is below 1.3:1 and would disappear on cheap panels.

Shadows are reserved for surfaces that genuinely float: the sticky configurator quote rail on scroll, dropdown menus, the mobile navigation sheet, and dialogs. One shadow only — `0 24px 64px rgba(0, 0, 0, 0.55)` — plus a 1px `border-strong` edge. Cards, buttons, inputs, and ivory plates use no shadow at all.

Ivory plates read as paper: flat fill, `border-ivory` 1px, `rounded.lg`, and a 1px internal hairline between ledger rows. Wood bands get a top inset 1px `gold-hairline` to suggest a lid edge and a bottom 1px rgba black 40% to suggest thickness. Forest bands get no highlight.

Focus is a 2px `focus-ring` outline at 2px offset, doubled by a 4px `gold-tint` halo on dark surfaces so it remains visible on gold buttons. Hover raises tone one stratum and lifts nothing. No glassmorphism except the navigation bar (86% `canvas-deep` with 12px backdrop blur), no glows, no noise overlays, no decorative blobs.

## Shapes

The shape language is **cased and square**: packaging is a box, so the interface is built from rectangles with 2px corners. Default radius is `rounded.sm` (2px) for buttons, inputs, chips, and option tiles; `rounded.md` (4px) for product and craftsmanship cards; `rounded.lg` (8px) for ivory plates, the quote panel, and the file dropzone. `rounded.full` is reserved for status dots, step markers, and badges — never for buttons or filter chips, which must stay rectangular to feel manufactured.

Separators are the primary ornament: 1px `border-subtle` rules between rows and columns, 1px `gold-hairline` for the 48px brass motif above section eyebrows, and thin vertical rules inside metric bands. No card carries a colored left border. Do not mix a 2px and an 8px radius inside the same cluster of controls. Icons are monoline at 1.5px stroke, 20–24px, `currentColor`, geometric and quiet (calipers, box outline, thread, stamp) — never emoji or filled pictograms. All controls retain a minimum 44×44 CSS px hit area regardless of visual size.

## Components

**Navigation.** 76px tall, `nav-bar` tone, 1px `border-subtle` bottom rule, wordmark in Bodoni Moda 20px with 0.06em tracking. Primary links use `nav-link` in `text-secondary`, 44px tall, hover to `text-primary` with a 1px gold underline that grows from the left in 180ms. The active link uses `nav-link-active` gold and stays underlined. The right side holds the language selector and one `button-primary` "Request a quote"; on scroll the bar keeps its 86% tint and gains a 1px `border-strong` bottom edge. Mobile collapses into a full-height sheet with 52px rows and the primary CTA pinned at the bottom.

**Buttons.** `button-primary` is gold with ink text, 52px tall, 2px radius, horizontal padding 24px, label in `typography.button` and sentence case. Hover shifts to `button-primary-hover` and translates -1px; active uses `button-primary-active` with no translation; disabled drops to 45% opacity with `cursor: not-allowed` and no hover. `button-secondary` is canvas with a 1px `border-strong` edge and warm-white text; hover raises background to `surface-raised` and text to `gold-pale`. `button-ghost` is a bare gold-deep text action with a 1px underline on hover, used for "View specification" style links. Every button shows `focus-visible` with the doubled gold ring and keeps a 44px minimum target. Loading replaces the label with a 16px spinner and preserves width.

**Filter chips.** `chip-filter` is a 44px transparent rectangle with 1px `border-subtle`, `label-caps` in `text-secondary`, and 2px radius. Hover raises border to `border-strong` and text to `text-primary`. Selected uses `chip-filter-selected` (gold tint fill, gold-pale text) plus a 1px `gold-hairline` border and a leading 6px dot; never rely on fill color alone. A "Clear filters" ghost action appears only when a filter is active.

**Inputs and selects.** 52px tall, `surface` fill, 1px `border-subtle`, 2px radius, 16px horizontal padding, `body-md` value text. Labels are `input-label` above the field with 8px gap; helper text is `caption` in `text-muted`; errors replace helper text in `danger` plus a 16px alert icon, with a 1px danger border and `aria-invalid`. Focus sets the border to `gold` and the doubled ring. Placeholders are `text-muted` at 4.5:1 minimum and never serve as labels. Textareas are 148px minimum with resize vertical. Dimension pairs (W × D × H in mm) are three inputs on one row with a shared label and unit suffix inside the field, so users do not type "mm".

**Configurator option tiles.** 108px minimum height, canvas fill, 1px `border-subtle`, 2px radius, 16px padding: a 24px monoline icon top-left, option name in `body-sm` warm white, and a one-line material note in `caption` `text-muted`. Hover raises to `surface`. Selected uses `option-tile-selected` with a 1px `gold-hairline` border and a 20px gold check at top-right; keyboard selection mirrors it with the focus ring. The step header is `label-caps` in gold for the active step, `text-muted` for pending, with a 32px `step-marker` / `step-marker-active` circle. Completed steps show a check, never a number.

**Quote rail and quote panel.** The sticky ivory rail uses `quote-panel`, a 12px `label-caps` eyebrow ("ESTIMATE"), the figure in `quote-figure` at 40px with the currency in `caption`, a hairline, then 3–4 cost-driver rows with label/value pairs, a disclaimer in `caption` `ink-muted` ("Indicative factory price; freight and duties excluded"), and a full-width `button-primary`. When the estimate updates, the figure cross-fades in 180ms and the rail never jumps in height. On phone the rail becomes a sticky bottom bar with the figure and an "Open estimate" action.

**Product cards.** `product-card` tone, 4px radius, 1px `border-subtle`, 24px padding, 4:5 image at top with 2px radius. Above the image: collection label in `eyebrow` `text-muted`. Title in `headline-sm`; below it two specification lines in `body-sm` with values in `spec-value`. Footer holds a quiet "View specification" ghost link and, where relevant, a `badge-verified` "In stock". Hover lifts image brightness by 4% and border to `border-strong` in 200ms; no card lift, no shadow. Empty filter results show a centered 48px box icon, one sentence, and a "Clear filters" secondary button.

**Craftsmanship tiles.** `craftsmanship-tile` wood tone, 4px radius, 24px padding, 1:1 macro image of the finish (piano lacquer, hot stamping foil, deboss, laser engraving, velvet, EVA). Title in `headline-sm`, technique in `caption` `text-secondary`, and a 44px "See the process" ghost link. One tile in the set may span 2 columns to break the rhythm. Do not put a colored left border on these.

**Metric band.** Full-width `metric-band` forest fill, 48px vertical padding, 3–4 figures in `display-md` with labels in `label-caps` `gold-pale`, separated by 1px `border-subtle` vertical rules. Counting animation is allowed once on entry, 600ms, stopped under `prefers-reduced-motion`. Figures are factual only (12+ years, 100% pre-shipment QC, 3–5 day sampling, export markets).

**RFQ form and dropzone.** Group fields in 4 steps or 3 fieldset clusters with hairline dividers, 24px internal rhythm. The `file-dropzone` is 148px, 4px radius, dashed 1px `border-strong`, centered 24px upload icon and copy in `body-sm`; dragging sets a gold-tinted background and a solid gold border. After upload, show filename chips with a remove control and a progress bar (2px, gold fill on `surface`). The submit button spans the field column at 52px; success replaces the form with a compact ivory panel confirming the reference number and the reply window, plus the WhatsApp and email actions repeated.

**Footer.** `canvas-deep`, 64px top padding, 1px `border-subtle` top rule. Four columns: brand and one-line positioning; products; capabilities; trade terms (MOQ, sampling, Incoterms, lead time, payment). `footer-heading` labels in `label-caps` `text-secondary`, links in `body-sm` `text-muted` at 44px row height. A final hairline row carries the factory address, business licence and certification placeholders, a compliance note, and the copyright in `caption`. Contact actions appear as `inline-link` with a 16px monoline icon.

**Motion and states.** Transitions 150–250ms on color and border, 600ms only for entrance fades and the metric count-up, easing `cubic-bezier(0.16, 1, 0.3, 1)`. Animate only `transform` and `opacity`. Every interactive element defines hover, focus-visible, active, disabled, loading, error, and empty states; every form field defines default, filled, focused, error, and disabled. Respect `prefers-reduced-motion` by removing translation and count-ups while keeping color transitions.

## Do's and Don'ts

- Do let photography and tonal layering create depth; don't add shadows to cards or ivory plates.
- Do use gold for one primary action per viewport plus one active state; don't flood a screen with gold fills or borders.
- Do set every display headline in Bodoni Moda at 28px or larger; don't use Archivo for editorial headings or center them over images.
- Do keep uppercase labels at 0.14em tracking or wider; don't set caps with default spacing.
- Do place facts on ivory specification plates; don't write long specifications as gold text on dark backgrounds.
- Do keep the accent contract: gold on canvas (9.7:1) and ink on ivory (16:1) pass; plain gold text on ivory (1.8:1) is forbidden — use `gold-ink`.
- Do maintain at least 4.5:1 contrast for normal text, 3:1 for large text and UI edges, and 44×44 CSS px touch targets.
- Do preserve 2px corners on controls and 4–8px on surfaces in a single cluster; don't mix pill and square shapes.
- Do vary section spacing (128/96/64) and tile spans; don't render three identical cards in a row.
- Do use real product photography of lacquer, leather, wood grain, and foil stamping; don't substitute CSS gradient blocks, decorative SVG "photos", stock handshakes, or emoji icons.
- Do state verifiable facts (since 2008, 12+ years, 3–5 day sampling, 100% pre-shipment QC) and label configurator output as indicative; don't invent "10× faster" or "99.9%" claims.
- Do write specific trade copy about MOQ, sampling, materials, and lead time; don't use "elevate", "seamless", "unleash", or lorem ipsum.
- Do keep the ivory surface to at most one third of a viewport; don't turn the whole page light or use pure black `#000000`.
