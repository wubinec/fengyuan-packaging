# ASSETS Manifest

## Local Sourced Images
- `https://sc02.alicdn.com/kf/H7a9a838bfc004ab5b1c16029cdf0a285V.png` - PS/AI Retouched: FY-C01 inner label completely removed, domestic tabletop/trashbin background replaced with clean dark studio surface.
- `https://sc02.alicdn.com/kf/H7099277fee27456c91369ab63dbe5474I.png` - PS/AI Retouched: Label removed, background replaced with luxury dark studio marble, showing clean cream leather interior.
- `https://sc02.alicdn.com/kf/H1c3ce30c8f124839a9fa5c27901a3e34J.png` - PS/AI Retouched: Replaced wooden desk background on the right, removed brand text, placed on clean luxury studio surface.
- `https://sc02.alicdn.com/kf/Hda0f384bfcd6425f95db01f27ed3d1a49.png` - PS/AI Retouched: Replaced plain white speckled countertop and room wall with dark studio luxury tabletop, removed brand text.
- `https://sc02.alicdn.com/kf/He9166b9101ec4cbc8bfdfef1ddeaae59s.jpg` - Real sample: Classic Cherry Wood Finish Lacquered Watch Box with brass clasp, ex-factory price ¥22, FOB ref $3.80 - $5.80 / pc.
- `https://sc02.alicdn.com/kf/H7f6ffd7d492b457db01a4f048776a2bcD.jpg` - Real sample: High-Gloss Obsidian Piano Lacquer Single Watch Box with polished silver latch, ex-factory price ¥54, FOB ref $9.50 - $14.50 / pc.
- `https://sc02.alicdn.com/kf/Hbe6cf7ccb0834a8087b125a8deef9f7dx.jpg` - Real sample: Full Luxury Presentation Suite with deep-green hard outer gift box, certificates and interior leather cushion, ex-factory price ¥56, FOB ref $9.80 - $15.00 / pc.
- `https://sc02.alicdn.com/kf/Hc4ad69a131644ef49d5beec208b41ff6K.jpg` - Real sample: Dark polished piano-lacquer hardwood presentation box with tailored outer card sleeve.
- `/assets/images/placeholder.svg` - Fallback vector placeholder for material and craft swatches.
