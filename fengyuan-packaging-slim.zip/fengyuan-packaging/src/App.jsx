import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Clock, 
  Layers, 
  Send, 
  CheckCircle2, 
  ChevronRight, 
  Sliders, 
  Box, 
  Award, 
  Globe2, 
  ArrowUpRight,
  Phone,
  Mail,
  MapPin,
  Check,
  PackageCheck,
  Languages
} from 'lucide-react';

export default function App() {
  // Language State: 'en' | 'zh'
  const [lang, setLang] = useState('en');

  // Configurator state for interactive quote builder
  const [boxType, setBoxType] = useState('single-watch');
  const [material, setMaterial] = useState('lacquer-wood');
  const [lining, setLining] = useState('leather');
  const [branding, setBranding] = useState('foil');
  const [quantity, setQuantity] = useState(500);

  // Filter state for catalog
  const [catalogFilter, setCatalogFilter] = useState('all');

  // Contact / RFQ state
  const [rfqSubmitted, setRfqSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    requirements: '',
    quantity: '500-1000'
  });

  // Multilingual Dictionary
  const t = {
    en: {
      brandSub: 'Fengyuan Luxury Craft • Since 2008',
      navCustom: 'Custom Configurator',
      navCatalog: 'Catalog & Pricing',
      navCraft: 'Craftsmanship',
      navFactory: 'Direct Factory',
      requestQuote: 'Request Quote',
      heroBadge: 'Verified Direct Factory • Guangzhou, China',
      heroTitle1: 'Bespoke Luxury',
      heroTitle2: 'Watch & Jewelry',
      heroTitle3: 'Packaging.',
      heroDesc: 'Empowering international horology brands, jewelry maisons, and luxury boutiques with tailor-made wooden cases, piano lacquer presentation boxes, and bespoke suites directly from our specialized Guangzhou workshop.',
      btnInteractive: 'Interactive Custom Builder',
      btnCatalog: 'View Product Catalog',
      stat1Val: '12+ Years',
      stat1Lbl: 'Verified Craft History',
      stat2Val: '3-5 Days',
      stat2Lbl: 'Rapid Custom Sampling',
      stat3Val: '200 Pcs',
      stat3Lbl: 'Flexible Entry MOQ',
      heroCardTag: 'Piano Black Lacquer',
      heroCardPriceLbl: 'Direct Factory FOB Range',
      configure: 'Configure',
      configSub: 'Precision OEM / ODM Engine',
      configTitle: 'Interactive Custom Box Builder',
      configDesc: 'Configure your brand specifications below to calculate instant FOB volume estimates and trigger our engineering review.',
      step1: '1. Box Architecture & Purpose',
      step2: '2. Exterior Core Material & Finish',
      step3: '3. Interior Lining & Cushion Structure',
      step4: '4. Custom Logo & Hardware Technique',
      step5: '5. Order Volume (MOQ: 200 pcs)',
      quoteSub: 'Live Configuration Quote',
      quoteTitle: 'Project Estimation',
      estFobUnit: 'Indicative FOB Unit Price',
      totalVolumeFob: 'Total Volume FOB:',
      freeDieline: 'Free Dieline Drawing Support',
      sampleTurnaround: 'Sample turnaround in 3–5 working days',
      btnLockSpec: 'Lock In Specification',
      catSub: 'Factory Catalog & Ready Molds',
      catTitle: 'Featured Collection',
      catDesc: 'Proven standard architectures ready for private-label customization with zero mold tooling fees.',
      filterAll: 'All Catalog',
      filterPiano: 'Piano Lacquer',
      filterWood: 'Lacquered Wood',
      filterSuite: 'Full Suites',
      fobPriceRange: 'FOB Price Range',
      inquireItem: 'Inquire Item',
      craftSub: 'In-House Production Capabilities',
      craftTitle: 'Finishing & Material Mastery',
      craftDesc: 'Direct factory control over every stage of woodworking, multi-layer lacquering, and custom jewelry-grade hardware fitting.',
      craft1Title: '12-Layer Piano Lacquer',
      craft1Desc: 'Repetitive hand-buffing and dust-free oven baking yielding an ultra-reflective mirror surface resistant to humidity and cracking.',
      craft2Title: 'Precision Foil Stamping',
      craft2Desc: 'Micro-registered hot foil stamping in matte gold, polished gold, rose gold, and silver on textured leatherette or lacquered lids.',
      craft3Title: 'Solid Hardware Hinges',
      craft3Desc: 'Heavyweight brass and stainless steel quadrant hinges engineered for smooth resistance and 10,000+ cycle opening lifespans.',
      craft4Title: 'Rapid 3-5 Day Sampling',
      craft4Desc: 'In-house digital CNC routing and physical proofing allowing complete physical prototypes shipped worldwide via DHL/FedEx.',
      factSub: 'Guangzhou Direct Manufacturing',
      factTitle: 'Rooted in Guangzhou Craftsmanship, Built for Global Luxury.',
      factDesc: 'Operating from Baiyun District, Guangzhou, Guangzhou Fengyuan Craft Products Co., Ltd. has specialized in bespoke packaging solutions for over 12 verified years. We combine authentic woodcraft tradition with precision production lines to serve international watchmakers, boutique jewelers, and packaging distributors across North America, Europe, and the Middle East.',
      factPoint1: 'Strict Quality Inspection: 100% individual surface and hinge check prior to maritime packaging.',
      factPoint2: 'Full Export Packaging Standard: Pearl-foam individual wrapping, shock-proof corner protectors and 5-ply corrugated export cartons.',
      factPoint3: 'Flexible Cooperation Terms: FOB Guangzhou/Shenzhen, EXW, and CIF sea/air freight door-to-door coordination.',
      factDirectTitle: 'Factory Direct Verification',
      factLoc: 'Location',
      factLocVal: 'Baiyun District, Guangzhou',
      factEst: 'Established',
      factEstVal: 'Since 2008 (12+ Yrs)',
      factCore: 'Core Specialization',
      factCoreVal: 'Watch & Jewelry Boxes',
      factPort: 'Export Delivery',
      factPortVal: 'FOB / CIF / Door-to-Door',
      factBuyerNote: 'Note to Overseas Buyers: Every prototype box is engineered with client-exclusive confidential molds. We do not re-sell customized brand logos to third parties.',
      rfqSub: 'Direct Factory Inquiry Desk',
      rfqTitle: 'Request a Sample or Custom Quote',
      rfqDesc: 'Provide your target box dimensions and quantities. Our engineering team responds within 12 hours with dielines and official FOB estimates.',
      rfqSuccessTitle: 'Inquiry Received',
      rfqSuccessDesc: 'Thank you for reaching out to FY-Packaging. Our direct sales representative will review your custom parameters and contact you via email shortly.',
      rfqAnother: 'Submit Another Inquiry',
      lblYourName: 'Your Name *',
      lblEmail: 'Business Email *',
      lblCompany: 'Company / Brand Name',
      lblQuantity: 'Estimated Quantity',
      lblReq: 'Specific Requirements / Box Dimensions',
      btnSendRfq: 'Send Inquiry to Engineering Team',
      retouchedNotice: 'High-Resolution Studio Retouched Sample'
    },
    zh: {
      brandSub: '丰源高档工艺包装 • 始于2008年',
      navCustom: '在线定制配置器',
      navCatalog: '产品型录与报价',
      navCraft: '核心生产工艺',
      navFactory: '源头工厂实力',
      requestQuote: '在线询价',
      heroBadge: '实体源头工厂 • 中国广州白云区',
      heroTitle1: '高端定制奢华',
      heroTitle2: '腕表与珠宝',
      heroTitle3: '工艺包装盒。',
      heroDesc: '广州丰源工艺制品有限公司专注于为全球中高端钟表品牌、珠宝首饰店及礼品商提供全案包装定制。涵盖高端钢琴烤漆木盒、复古原木盒、精美皮盒及全套包装礼盒。',
      btnInteractive: '进入在线定制计算器',
      btnCatalog: '查看现货与标款产品',
      stat1Val: '12+ 年',
      stat1Lbl: '诚信实体验证历史',
      stat2Val: '3-5 天',
      stat2Lbl: '快速来样/图打样',
      stat3Val: '200 个',
      stat3Lbl: '灵活起订量 (MOQ)',
      heroCardTag: '高光曜石黑钢琴漆表盒',
      heroCardPriceLbl: '源头工厂 FOB 美金参考价',
      configure: '进入定制',
      configSub: '高精度 OEM / ODM 测算引擎',
      configTitle: '在线包装定制配置器',
      configDesc: '选择您的产品规格与工艺要求，系统将即时生成阶梯出海 FOB 参考报价并提交工程评审。',
      step1: '1. 盒型结构与使用场景',
      step2: '2. 外盒材质与饰面工艺',
      step3: '3. 内部衬垫与结构固定',
      step4: '4. 品牌定制 Logo 与五金配件',
      step5: '5. 预订采购量 (起订量: 200个)',
      quoteSub: '实时定制方案测算',
      quoteTitle: '工程造价评估',
      estFobUnit: '预估单只 FOB 参考价',
      totalVolumeFob: '整批货值 FOB 总额:',
      freeDieline: '免费提供工程刀模与刀线图纸',
      sampleTurnaround: '打样周期 3–5 个工作日',
      btnLockSpec: '锁定参数并提交询价',
      catSub: '工厂现款与成熟模具库',
      catTitle: '精选代表性款式',
      catDesc: '免收高昂模具费，成熟盒型可快速加印自主品牌 Logo 并安排大货排产。',
      filterAll: '全部型录',
      filterPiano: '高光钢琴烤漆',
      filterWood: '复古木纹烤漆',
      filterSuite: '高档套盒系列',
      fobPriceRange: 'FOB 离岸价格参考',
      inquireItem: '咨询该款',
      craftSub: '厂内核心加工制造能力',
      craftTitle: '材质与表面精湛工艺',
      craftDesc: '全流程厂内自主掌控：从实木榫卯开料、多层无尘喷漆烘烤到高档五金精准铰合。',
      craft1Title: '12道无尘钢琴漆工艺',
      craft1Desc: '反复手工打磨与无尘烘烤，表面犹如镜面通透平整，耐湿热抗开裂。',
      craft2Title: '精密烫金 / 烫银',
      craft2Desc: '支持哑金、亮金、玫瑰金、镭射银在皮革或漆面上的精准套位烫印。',
      craft3Title: '高质感承重五金铰链',
      craft3Desc: '精选纯铜与精钢折叠合页，开合阻尼感顺滑，耐受上万次往复开合。',
      craft4Title: '3-5天快速打样出样',
      craft4Desc: '厂内配备数控打样机，配合样品师傅快速制作实体样盒并通过国际快递交付客户。',
      factSub: '广州源头实体制造基地',
      factTitle: '立足广州工艺底蕴，服务全球高端品牌。',
      factDesc: '广州丰源工艺制品有限公司坐落于广州市白云区钟落潭镇，专注定制包装生产超过12年。我们凭借扎实的木工工艺与严格的品控流程，长期为北美、欧洲及中东地区采购商提供稳定的供应链支持。',
      factPoint1: '严格出货质检：出厂前 100% 逐只外观光泽与五金开合检查。',
      factPoint2: '全套外贸防潮抗震包装：单个珍珠棉袋密封 + 专用硬质内盒 + 5层加厚瓦楞外箱。',
      factPoint3: '灵活出海贸易条款：支持广州/深圳港口 FOB，或 EXW 工厂交货及门到门海空运。',
      factDirectTitle: '工厂直营资质核验',
      factLoc: '工厂地址',
      factLocVal: '广东省广州市白云区钟落潭镇金盆中路14号',
      factEst: '创立与历史',
      factEstVal: '2008年创立 (12+年资历)',
      factCore: '核心主营',
      factCoreVal: '手表盒 / 首饰盒 / 礼盒包装',
      factPort: '交货方式',
      factPortVal: 'FOB / CIF / 门到门',
      factBuyerNote: '致海外客户声明：客户定制的所有专版与品牌 Logo 均签署保密协议，绝不向第三方倒卖。',
      rfqSub: '外贸业务直联窗口',
      rfqTitle: '申请实物样品或获取正式报价',
      rfqDesc: '填写您的预估尺寸与数量，工程业务团队将在 12 小时内为您回复刀模图与出海报价单。',
      rfqSuccessTitle: '询盘已成功送达',
      rfqSuccessDesc: '感谢联系丰源包装！专属外贸业务经理将仔细评审您的定制参数并尽快邮件与您联系。',
      rfqAnother: '继续提交其他定制需求',
      lblYourName: '您的姓名 *',
      lblEmail: '商业电子邮箱 *',
      lblCompany: '公司 / 品牌名称',
      lblQuantity: '预估单批采购数量',
      lblReq: '定制规格尺寸与特殊工艺要求',
      btnSendRfq: '立即发送定制询价单',
      retouchedNotice: '摄影棚高光精修实拍场景'
    }
  }[lang];

  // Calculate estimated FOB price based on user custom configuration
  const calculateEstimate = () => {
    let base = 4.5;
    if (material === 'lacquer-wood') base += 5.5;
    if (material === 'hardwood-cherry') base += 3.2;
    if (material === 'pu-leather') base += 2.0;
    if (material === 'rigid-board') base += 1.0;

    if (lining === 'leather') base += 1.5;
    if (lining === 'velvet') base += 1.0;
    if (lining === 'eva') base += 0.8;

    if (branding === 'metal-plate') base += 1.2;
    if (branding === 'foil') base += 0.5;

    // Quantity tier discount
    let discount = 1.0;
    if (quantity >= 2000) discount = 0.75;
    else if (quantity >= 1000) discount = 0.85;
    else if (quantity >= 500) discount = 0.95;

    const unitPrice = (base * discount).toFixed(2);
    const totalPrice = (unitPrice * quantity).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    return { unitPrice, totalPrice };
  };

  const estimate = calculateEstimate();

  const products = [
    {
      id: 'FY-W22',
      title: lang === 'en' ? 'Heritage Lacquered Cherry Wood Watch Box' : '复古亮光樱桃木纹翻盖表盒',
      category: 'lacquer-wood',
      image: 'https://sc02.alicdn.com/kf/H7099277fee27456c91369ab63dbe5474I.png',
      moq: '200 pcs',
      fobRange: '$3.80 – $5.80',
      exFactoryRef: '¥22 Base',
      features: lang === 'en' 
        ? ['Studio Retouched (Label Cleared)', 'Brass Hardware Clasp', 'Textured Cushion Lining', 'Beveled Edge Framing']
        : ['已去除内标签 & 高级大理石场景', '复古纯铜扣锁与合页', '仿皮纹质感表枕内衬', '精细倒角木工工艺']
    },
    {
      id: 'FY-W54',
      title: lang === 'en' ? 'Obsidian High-Gloss Piano Lacquer Watch Case' : '曜石黑高光钢琴漆单只腕表盒',
      category: 'piano-lacquer',
      image: 'https://sc02.alicdn.com/kf/H1c3ce30c8f124839a9fa5c27901a3e34J.png',
      moq: '200 pcs',
      fobRange: '$9.50 – $14.50',
      exFactoryRef: '¥54 Base',
      features: lang === 'en'
        ? ['Studio Retouched (Desk Background Removed)', 'Polished Silver Push Latch', 'Cream Grain Leather Interior', 'Single Watch Display']
        : ['已去桌面背景 & 影棚高光', '银色弹簧按压锁扣', '米白皮纹内衬与表枕', '单只腕表典藏收纳']
    },
    {
      id: 'FY-S56',
      title: lang === 'en' ? 'Grand Horology Collector Presentation Suite' : '豪华腕表典藏全套礼盒套组',
      category: 'luxury-suite',
      image: 'https://sc02.alicdn.com/kf/Hda0f384bfcd6425f95db01f27ed3d1a49.png',
      moq: '200 pcs',
      fobRange: '$9.80 – $15.00',
      exFactoryRef: '¥56 Base',
      features: lang === 'en'
        ? ['Studio Retouched (Pure Presentation Backdrop)', 'Certificate Wallets & Inserts', 'Lacquered Inner Vault', 'Microfiber Protective Pillow']
        : ['已去桌面杂色背景 & 影棚质感', '证书保修卡插袋全配', '独立烤漆内盒', '超纤柔软防刮表枕']
    },
    {
      id: 'FY-C01',
      title: lang === 'en' ? 'Bespoke Executive Hardwood Gift Vault' : '高级定制实木烤漆多功能收纳盒',
      category: 'lacquer-wood',
      image: 'https://sc02.alicdn.com/kf/H7a9a838bfc004ab5b1c16029cdf0a285V.png',
      moq: '300 pcs',
      fobRange: '$8.50 – $13.00',
      exFactoryRef: 'Custom ODM',
      features: lang === 'en'
        ? ['Studio Retouched (Label Removed & Neutral Surface)', 'Custom Sleeving Box', 'Ultra-Suede Recessed Cushion', 'Laser / Foil Logo Ready']
        : ['已去内盖标签 & 暗色台面', '配套专属定制封套纸盒', '麂皮绒防磨内部凹槽', '支持激光雕刻与烫金']
    }
  ];

  const filteredProducts = catalogFilter === 'all' 
    ? products 
    : products.filter(p => p.category === catalogFilter);

  const handleRfqSubmit = (e) => {
    e.preventDefault();
    setRfqSubmitted(true);
    // Automatically build mailto with client specifications
    const subject = encodeURIComponent(`[RFQ Inquiry] ${formData.company || formData.name} - Custom Packaging Project`);
    const body = encodeURIComponent(
      `Dear Luke Wu / FY-Packaging Sales Team,\n\n` +
      `I would like to request an official quotation with the following project parameters:\n\n` +
      `• Contact Name: ${formData.name}\n` +
      `• Email: ${formData.email}\n` +
      `• Company / Brand: ${formData.company || 'N/A'}\n` +
      `• Target Order Quantity: ${formData.quantity} pcs\n` +
      `• Project Specifications / Dimensions: \n${formData.requirements || 'Standard model reference'}\n\n` +
      `Please provide dieline drawings and FOB Guangzhou/Shenzhen quotation.\n\n` +
      `Best regards,\n${formData.name}`
    );
    window.open(`mailto:13420913206@163.com?subject=${subject}&body=${body}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#0D1117] text-[#F8F9FA]">
      {/* 1. Header / Navigation */}
      <header className="sticky top-0 z-50 bg-[#0D1117]/90 backdrop-blur-md border-b border-[#C5A059]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 border border-[#C5A059] flex items-center justify-center bg-[#141A23]">
              <span className="font-serif text-[#C5A059] text-xl font-bold tracking-widest">FY</span>
            </div>
            <div>
              <div className="font-serif text-lg tracking-wider text-[#F8F9FA] font-semibold">FY-PACKAGING</div>
              <div className="text-[10px] tracking-widest text-[#C5A059] uppercase">{t.brandSub}</div>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-8 text-sm uppercase tracking-wider text-[#A3B1C2]">
            <a href="#custom-builder" className="hover:text-[#C5A059] transition-colors">{t.navCustom}</a>
            <a href="#catalog" className="hover:text-[#C5A059] transition-colors">{t.navCatalog}</a>
            <a href="#craftsmanship" className="hover:text-[#C5A059] transition-colors">{t.navCraft}</a>
            <a href="#factory" className="hover:text-[#C5A059] transition-colors">{t.navFactory}</a>
          </nav>

          <div className="flex items-center space-x-3">
            {/* Language Switcher */}
            <button
              onClick={() => setLang(lang === 'en' ? 'zh' : 'en')}
              className="flex items-center space-x-1 px-3 py-1.5 border border-[#C5A059]/30 text-xs text-[#DFC48D] hover:border-[#C5A059] bg-[#141A23] transition-all"
              title="Switch Language / 切换中英文"
            >
              <Languages className="w-3.5 h-3.5 text-[#C5A059]" />
              <span className="font-semibold">{lang === 'en' ? '中 / EN' : 'EN / 中'}</span>
            </button>

            <a 
              href="#rfq" 
              className="inline-flex items-center px-4 sm:px-5 py-2.5 bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-widest hover:bg-[#DFC48D] transition-colors"
            >
              <span>{t.requestQuote}</span>
              <ArrowUpRight className="ml-1 w-4 h-4" />
            </a>
          </div>
        </div>
      </header>

      {/* 2. Hero Section */}
      <section className="relative pt-24 pb-20 md:pt-32 md:pb-32 overflow-hidden border-b border-[#C5A059]/15">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C5A059_1px,transparent_1px)] [background-size:24px_24px]"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#141A23] border border-[#C5A059]/30 text-[#C5A059] text-xs tracking-widest uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t.heroBadge}</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-[#F8F9FA] leading-[1.15]">
                {t.heroTitle1} <br />
                <span className="luxury-gradient-text italic font-serif">{t.heroTitle2}</span> {t.heroTitle3}
              </h1>

              <p className="text-base sm:text-lg text-[#A3B1C2] max-w-2xl font-light leading-relaxed">
                {t.heroDesc}
              </p>

              <div className="pt-4 flex flex-wrap gap-4 items-center">
                <a 
                  href="#custom-builder"
                  className="px-7 py-3.5 bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-widest hover:bg-[#DFC48D] transition-all flex items-center space-x-2"
                >
                  <Sliders className="w-4 h-4" />
                  <span>{t.btnInteractive}</span>
                </a>
                <a 
                  href="#catalog"
                  className="px-7 py-3.5 bg-[#141A23] border border-[#C5A059]/40 text-[#F8F9FA] text-xs font-semibold uppercase tracking-widest hover:border-[#C5A059] transition-all flex items-center space-x-2"
                >
                  <Box className="w-4 h-4" />
                  <span>{t.btnCatalog}</span>
                </a>
              </div>

              {/* Verified Trust Badges */}
              <div className="pt-8 grid grid-cols-3 gap-6 border-t border-[#C5A059]/20 text-xs">
                <div>
                  <div className="font-serif text-xl text-[#C5A059] font-medium">{t.stat1Val}</div>
                  <div className="text-[#A3B1C2] mt-1">{t.stat1Lbl}</div>
                </div>
                <div>
                  <div className="font-serif text-xl text-[#C5A059] font-medium">{t.stat2Val}</div>
                  <div className="text-[#A3B1C2] mt-1">{t.stat2Lbl}</div>
                </div>
                <div>
                  <div className="font-serif text-xl text-[#C5A059] font-medium">{t.stat3Val}</div>
                  <div className="text-[#A3B1C2] mt-1">{t.stat3Lbl}</div>
                </div>
              </div>
            </div>

            {/* Hero Visual Card with PS-retouched Clean Image */}
            <div className="lg:col-span-5 relative">
              <div className="luxury-card p-4 relative">
                <div className="relative overflow-hidden aspect-[4/3] bg-black">
                  <img 
                    src="https://sc02.alicdn.com/kf/H7099277fee27456c91369ab63dbe5474I.png" 
                    alt="Retouched Studio Quality Watch Box"
                    className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700" 
                  />
                  <div className="absolute top-3 right-3 bg-[#0A2118]/90 border border-emerald-500/50 px-2.5 py-1 text-[11px] text-emerald-300 flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{t.retouchedNotice}</span>
                  </div>
                  <div className="absolute bottom-3 left-3 bg-[#0D1117]/85 backdrop-blur-sm border border-[#C5A059]/40 px-3 py-1.5 text-xs text-[#F8F9FA]">
                    <span className="text-[#C5A059] font-mono font-medium">Ref. FY-W22</span> • {lang === 'en' ? 'Cleaned Interior Lid' : '已去内标亮光樱桃木'}
                  </div>
                </div>
                <div className="p-4 bg-[#141A23] border-t border-[#C5A059]/20 flex justify-between items-center text-xs">
                  <div>
                    <div className="text-[#A3B1C2]">{t.heroCardPriceLbl}</div>
                    <div className="font-mono text-base text-[#C5A059] font-semibold mt-0.5">$3.80 – $5.80 / pc</div>
                  </div>
                  <a href="#custom-builder" className="text-[#C5A059] underline tracking-wider uppercase flex items-center">
                    <span>{t.configure}</span>
                    <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Interactive Custom Configurator */}
      <section id="custom-builder" className="py-20 bg-[#10151E] border-b border-[#C5A059]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="text-xs uppercase tracking-widest text-[#C5A059] mb-2 font-mono">{t.configSub}</div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#F8F9FA]">{t.configTitle}</h2>
            <p className="text-sm text-[#A3B1C2] mt-3">
              {t.configDesc}
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-start">
            {/* Step Controls */}
            <div className="lg:col-span-8 space-y-8 bg-[#141A23] p-6 sm:p-8 border border-[#C5A059]/20">
              {/* Step 1: Box Style */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step1}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  {[
                    { id: 'single-watch', label: lang === 'en' ? 'Single Watch Box' : '单只装腕表盒', note: lang === 'en' ? 'Standard / Luxury' : '经典主流款式' },
                    { id: 'dual-watch', label: lang === 'en' ? 'Dual Watch Case' : '双表位对表盒', note: lang === 'en' ? 'Collector Edition' : '收藏对表礼盒' },
                    { id: 'jewelry-vault', label: lang === 'en' ? 'Jewelry / Ring Box' : '首饰/珠宝戒指盒', note: lang === 'en' ? 'Hinged Keepsake' : '翻盖精密五金' },
                    { id: 'full-suite', label: lang === 'en' ? 'Full Luxury Suite' : '豪华全套包装组', note: lang === 'en' ? 'Inner Box + Outer Sleeve' : '外硬盒+内盒+卡槽' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setBoxType(item.id)}
                      className={`p-3 text-left border transition-all ${
                        boxType === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.note}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Outer Material */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step2}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  {[
                    { id: 'lacquer-wood', label: lang === 'en' ? 'Piano Lacquer Wood' : '镜面钢琴烤漆', desc: lang === 'en' ? 'Mirror Gloss Coating' : '多层手工抛光' },
                    { id: 'hardwood-cherry', label: lang === 'en' ? 'Cherry Stained Wood' : '亮光樱桃木纹', desc: lang === 'en' ? 'Natural Grain Lacquer' : '天然木纹清漆' },
                    { id: 'pu-leather', label: lang === 'en' ? 'Premium Saffiano PU' : '高档十字纹PU皮', desc: lang === 'en' ? 'Scratch-Proof Leatherette' : '耐磨防刮质感' },
                    { id: 'rigid-board', label: lang === 'en' ? 'Touch Special Paper' : '触感特种艺术纸', desc: lang === 'en' ? 'Cost-Effective Luxury' : '轻奢高性价比' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setMaterial(item.id)}
                      className={`p-3 text-left border transition-all ${
                        material === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Interior Insert & Lining */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step3}
                </label>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  {[
                    { id: 'leather', label: lang === 'en' ? 'Grain Microfiber PU' : '荔枝纹细腻仿皮', desc: lang === 'en' ? 'Supple & Durable' : '防刮耐压柔韧' },
                    { id: 'velvet', label: lang === 'en' ? 'High-Density Velvet' : '高密柔顺天鹅绒', desc: lang === 'en' ? 'Plush Jewel Protection' : '典雅珠宝保护' },
                    { id: 'eva', label: lang === 'en' ? 'Recessed High-Resil EVA' : '高弹EVA精雕内托', desc: lang === 'en' ? 'Custom Die-Cut' : '定制精密贴合' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setLining(item.id)}
                      className={`p-3 text-left border transition-all ${
                        lining === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 4: Branding Technique */}
              <div>
                <label className="text-xs uppercase tracking-widest text-[#C5A059] block mb-3 font-semibold">
                  {t.step4}
                </label>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  {[
                    { id: 'foil', label: lang === 'en' ? 'Gold / Silver Hot Stamping' : '高温烫金 / 烫银', desc: lang === 'en' ? 'Crisp Metallic Imprint' : '高清晰金属镜面' },
                    { id: 'metal-plate', label: lang === 'en' ? 'Inlaid Brass / Steel Badge' : '嵌入式纯铜/钢标牌', desc: lang === 'en' ? 'Solid Metal Emblem' : '厚重奢华立体标' },
                    { id: 'deboss', label: lang === 'en' ? 'Precision Blind Deboss' : '微压凹立体压纹', desc: lang === 'en' ? 'Subtle Tactile Relief' : '低调高级触感' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => setBranding(item.id)}
                      className={`p-3 text-left border transition-all ${
                        branding === item.id 
                          ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F8F9FA]' 
                          : 'border-[#C5A059]/15 bg-[#0D1117] text-[#A3B1C2] hover:border-[#C5A059]/40'
                      }`}
                    >
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-[10px] text-[#A3B1C2] mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 5: Quantity Slider */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
                    {t.step5}
                  </label>
                  <span className="font-mono text-[#F8F9FA] text-sm font-semibold">{quantity.toLocaleString()} pcs</span>
                </div>
                <input 
                  type="range" 
                  min="200" 
                  max="5000" 
                  step="100"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full h-1.5 bg-[#0D1117] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
                />
                <div className="flex justify-between text-[11px] text-[#A3B1C2] mt-1 font-mono">
                  <span>200 (Pilot / 试单)</span>
                  <span>500 (Standard / 常规)</span>
                  <span>1,000 (Bulk / 批量)</span>
                  <span>5,000+ (Full Container / 集装箱)</span>
                </div>
              </div>
            </div>

            {/* Instant Pricing & RFQ Summary Card */}
            <div className="lg:col-span-4 bg-[#141A23] border border-[#C5A059] p-6 sticky top-28 space-y-6">
              <div className="border-b border-[#C5A059]/20 pb-4">
                <div className="text-[11px] uppercase tracking-widest text-[#C5A059] font-mono">{t.quoteSub}</div>
                <div className="font-serif text-xl text-[#F8F9FA] mt-1">{t.quoteTitle}</div>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'en' ? 'Style' : '定制盒型'}</span>
                  <span className="font-medium capitalize text-white">{boxType.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'en' ? 'Exterior' : '外壳材质'}</span>
                  <span className="font-medium capitalize text-white">{material.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'en' ? 'Lining' : '内衬选择'}</span>
                  <span className="font-medium capitalize text-white">{lining}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'en' ? 'Branding' : 'Logo工艺'}</span>
                  <span className="font-medium capitalize text-white">{branding.replace('-', ' ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#C5A059]/10">
                  <span className="text-[#A3B1C2]">{lang === 'en' ? 'Volume' : '采购批量'}</span>
                  <span className="font-mono text-white">{quantity.toLocaleString()} pcs</span>
                </div>
              </div>

              {/* Price Calculation Box */}
              <div className="bg-[#0D1117] p-4 border border-[#C5A059]/30 text-center">
                <div className="text-[10px] uppercase tracking-wider text-[#A3B1C2]">{t.estFobUnit}</div>
                <div className="font-mono text-3xl font-bold text-[#C5A059] mt-1">${estimate.unitPrice}</div>
                <div className="text-[11px] text-[#A3B1C2] mt-1">{t.totalVolumeFob} <span className="font-mono text-white font-medium">${estimate.totalPrice}</span></div>
              </div>

              <div className="space-y-2 text-[11px] text-[#A3B1C2]">
                <div className="flex items-center space-x-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{t.freeDieline}</span>
                </div>
                <div className="flex items-center space-x-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{t.sampleTurnaround}</span>
                </div>
              </div>

              <a 
                href="#rfq"
                className="w-full block py-3 text-center bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-widest hover:bg-[#DFC48D] transition-all"
              >
                {t.btnLockSpec}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Product Catalog & Showcase */}
      <section id="catalog" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#C5A059] mb-2 font-mono">{t.catSub}</div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#F8F9FA]">{t.catTitle}</h2>
            <p className="text-sm text-[#A3B1C2] mt-2 max-w-xl">
              {t.catDesc}
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-2 mt-6 md:mt-0 text-xs">
            {[
              { id: 'all', label: t.filterAll },
              { id: 'piano-lacquer', label: t.filterPiano },
              { id: 'lacquer-wood', label: t.filterWood },
              { id: 'luxury-suite', label: t.filterSuite }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setCatalogFilter(tab.id)}
                className={`px-4 py-2 border transition-all ${
                  catalogFilter === tab.id
                    ? 'border-[#C5A059] bg-[#C5A059] text-[#0D1117] font-semibold'
                    : 'border-[#C5A059]/20 text-[#A3B1C2] hover:border-[#C5A059]/50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map(p => (
            <div key={p.id} className="luxury-card overflow-hidden flex flex-col justify-between group">
              <div>
                <div className="relative aspect-[4/3] bg-black overflow-hidden">
                  <img 
                    src={p.image} 
                    alt={p.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500" 
                  />
                  <div className="absolute top-3 left-3 bg-[#0D1117]/85 backdrop-blur-sm border border-[#C5A059]/30 px-2.5 py-1 text-[11px] font-mono text-[#C5A059]">
                    {p.id}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-serif text-lg text-white font-medium">{p.title}</h3>
                  <div className="mt-4 space-y-1.5 text-xs text-[#A3B1C2]">
                    {p.features.map((feat, idx) => (
                      <div key={idx} className="flex items-center space-x-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]"></span>
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <div className="pt-4 border-t border-[#C5A059]/15 flex items-center justify-between text-xs">
                  <div>
                    <div className="text-[10px] uppercase text-[#A3B1C2]">{t.fobPriceRange}</div>
                    <div className="font-mono text-sm text-[#C5A059] font-semibold mt-0.5">{p.fobRange}</div>
                    <div className="text-[10px] text-[#A3B1C2]">MOQ: {p.moq}</div>
                  </div>

                  <a 
                    href="#rfq"
                    className="px-3.5 py-2 border border-[#C5A059]/40 text-[#F8F9FA] hover:bg-[#C5A059] hover:text-[#0D1117] transition-all font-medium"
                  >
                    {t.inquireItem}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Craftsmanship & Finishes Matrix */}
      <section id="craftsmanship" className="py-20 bg-[#141A23] border-t border-b border-[#C5A059]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-xs uppercase tracking-widest text-[#C5A059] mb-2 font-mono">{t.craftSub}</div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#F8F9FA]">{t.craftTitle}</h2>
            <p className="text-sm text-[#A3B1C2] mt-3">
              {t.craftDesc}
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6 text-sm">
            <div className="p-6 bg-[#0D1117] border border-[#C5A059]/20 space-y-3">
              <div className="w-10 h-10 border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-base text-white">{t.craft1Title}</h3>
              <p className="text-xs text-[#A3B1C2] leading-relaxed">
                {t.craft1Desc}
              </p>
            </div>

            <div className="p-6 bg-[#0D1117] border border-[#C5A059]/20 space-y-3">
              <div className="w-10 h-10 border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-base text-white">{t.craft2Title}</h3>
              <p className="text-xs text-[#A3B1C2] leading-relaxed">
                {t.craft2Desc}
              </p>
            </div>

            <div className="p-6 bg-[#0D1117] border border-[#C5A059]/20 space-y-3">
              <div className="w-10 h-10 border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-base text-white">{t.craft3Title}</h3>
              <p className="text-xs text-[#A3B1C2] leading-relaxed">
                {t.craft3Desc}
              </p>
            </div>

            <div className="p-6 bg-[#0D1117] border border-[#C5A059]/20 space-y-3">
              <div className="w-10 h-10 border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-base text-white">{t.craft4Title}</h3>
              <p className="text-xs text-[#A3B1C2] leading-relaxed">
                {t.craft4Desc}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Direct Factory Credibility & About */}
      <section id="factory" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono">{t.factSub}</div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#F8F9FA]">
              {t.factTitle}
            </h2>
            <p className="text-sm text-[#A3B1C2] leading-relaxed">
              {t.factDesc}
            </p>

            <div className="space-y-3 pt-2 text-xs">
              <div className="flex items-start space-x-3">
                <Check className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <span>{t.factPoint1}</span>
              </div>
              <div className="flex items-start space-x-3">
                <Check className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <span>{t.factPoint2}</span>
              </div>
              <div className="flex items-start space-x-3">
                <Check className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <span>{t.factPoint3}</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 bg-[#141A23] border border-[#C5A059]/30 p-8 space-y-6">
            <h3 className="font-serif text-xl text-white">{t.factDirectTitle}</h3>
            <div className="grid grid-cols-2 gap-4 text-xs font-mono">
              <div className="p-3 bg-[#0D1117] border border-[#C5A059]/15">
                <div className="text-[#A3B1C2]">{t.factLoc}</div>
                <div className="text-white mt-1">{t.factLocVal}</div>
              </div>
              <div className="p-3 bg-[#0D1117] border border-[#C5A059]/15">
                <div className="text-[#A3B1C2]">{t.factEst}</div>
                <div className="text-white mt-1">{t.factEstVal}</div>
              </div>
              <div className="p-3 bg-[#0D1117] border border-[#C5A059]/15">
                <div className="text-[#A3B1C2]">{t.factCore}</div>
                <div className="text-white mt-1">{t.factCoreVal}</div>
              </div>
              <div className="p-3 bg-[#0D1117] border border-[#C5A059]/15">
                <div className="text-[#A3B1C2]">{t.factPort}</div>
                <div className="text-white mt-1">{t.factPortVal}</div>
              </div>
            </div>

            <div className="p-4 bg-[#C5A059]/10 border border-[#C5A059]/40 text-xs text-[#DFC48D]">
              {t.factBuyerNote}
            </div>
          </div>
        </div>
      </section>

      {/* 7. RFQ / Inquiry Engine */}
      <section id="rfq" className="py-20 bg-[#10151E] border-t border-[#C5A059]/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#141A23] border border-[#C5A059] p-8 sm:p-12">
            <div className="text-center max-w-xl mx-auto mb-8">
              <div className="text-xs uppercase tracking-widest text-[#C5A059] font-mono mb-2">{t.rfqSub}</div>
              <h2 className="font-serif text-3xl text-white">{t.rfqTitle}</h2>
              <p className="text-xs text-[#A3B1C2] mt-2">
                {t.rfqDesc}
              </p>

              {/* Direct Fast Contact Badges */}
              <div className="mt-6 flex flex-wrap justify-center gap-4 text-xs">
                <a 
                  href="https://wa.me/8613420913206?text=Hello%20Luke%20Wu%2C%20I%20am%20interested%20in%20custom%20watch%20boxes%20from%20FY-Packaging." 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-[#25D366]/15 border border-[#25D366]/40 text-[#25D366] hover:bg-[#25D366] hover:text-black transition-all"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>WhatsApp: +86 13420913206 (Luke Wu)</span>
                </a>
                <a 
                  href="mailto:13420913206@163.com?subject=Inquiry%20from%20FYbox%20Website" 
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-[#C5A059]/15 border border-[#C5A059]/40 text-[#DFC48D] hover:bg-[#C5A059] hover:text-black transition-all"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email: 13420913206@163.com</span>
                </a>
              </div>
            </div>

            {rfqSubmitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <PackageCheck className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl text-white">{t.rfqSuccessTitle}</h3>
                <p className="text-xs text-[#A3B1C2] max-w-md mx-auto">
                  {t.rfqSuccessDesc}
                </p>
                <button
                  onClick={() => setRfqSubmitted(false)}
                  className="px-6 py-2.5 bg-[#C5A059] text-[#0D1117] text-xs font-semibold uppercase tracking-wider mt-4"
                >
                  {t.rfqAnother}
                </button>
              </div>
            ) : (
              <form onSubmit={handleRfqSubmit} className="space-y-6 text-xs">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[#A3B1C2] uppercase tracking-wider mb-2">{t.lblYourName}</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="e.g. Alexander Wright"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1117] border border-[#C5A059]/30 text-white focus:border-[#C5A059] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[#A3B1C2] uppercase tracking-wider mb-2">{t.lblEmail}</label>
                    <input 
                      required 
                      type="email" 
                      placeholder="alexander@brandwatch.com"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1117] border border-[#C5A059]/30 text-white focus:border-[#C5A059] outline-none"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[#A3B1C2] uppercase tracking-wider mb-2">{t.lblCompany}</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Zurich Timepieces Ltd."
                      value={formData.company}
                      onChange={(e) => setFormData({...formData, company: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1117] border border-[#C5A059]/30 text-white focus:border-[#C5A059] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[#A3B1C2] uppercase tracking-wider mb-2">{t.lblQuantity}</label>
                    <select 
                      value={formData.quantity}
                      onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1117] border border-[#C5A059]/30 text-white focus:border-[#C5A059] outline-none"
                    >
                      <option value="200-500">200 - 500 pcs (Pilot Order)</option>
                      <option value="500-1000">500 - 1,000 pcs (Standard Batch)</option>
                      <option value="1000-3000">1,000 - 3,000 pcs (Commercial Scale)</option>
                      <option value="3000+">3,000+ pcs (Container Wholesale)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[#A3B1C2] uppercase tracking-wider mb-2">{t.lblReq}</label>
                  <textarea 
                    rows={4}
                    placeholder="Provide your watch case dimensions, preferred lacquer tone, interior insert setup, or custom logo finishing..."
                    value={formData.requirements}
                    onChange={(e) => setFormData({...formData, requirements: e.target.value})}
                    className="w-full px-4 py-3 bg-[#0D1117] border border-[#C5A059]/30 text-white focus:border-[#C5A059] outline-none"
                  ></textarea>
                </div>

                <div className="pt-2">
                  <button 
                    type="submit"
                    className="w-full py-4 bg-[#C5A059] text-[#0D1117] font-semibold uppercase tracking-widest text-xs hover:bg-[#DFC48D] transition-colors flex items-center justify-center space-x-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{t.btnSendRfq}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* 8. Footer */}
      <footer className="py-12 bg-[#0D1117] border-t border-[#C5A059]/15 text-xs text-[#A3B1C2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-3">
            <div className="font-serif text-lg text-white font-semibold">FY-PACKAGING</div>
            <p className="text-[11px] leading-relaxed">
              Guangzhou Fengyuan Craft Products Co., Ltd.<br />
              Specialized manufacturer of bespoke luxury watch packaging and presentation craft boxes.
            </p>
          </div>

          <div>
            <div className="text-white font-semibold uppercase tracking-wider mb-3">Product Ranges</div>
            <ul className="space-y-1.5 text-[11px]">
              <li>Piano Lacquer Watch Cases</li>
              <li>Cherry Finish Wooden Boxes</li>
              <li>Jewelry & Keepsake Vaults</li>
              <li>Full Outer & Inner Packaging Suites</li>
            </ul>
          </div>

          <div>
            <div className="text-white font-semibold uppercase tracking-wider mb-3">Custom Services</div>
            <ul className="space-y-1.5 text-[11px]">
              <li>OEM / ODM Rapid Sampling</li>
              <li>Dieline & Vector Layout Support</li>
              <li>Laser Engraving & Hot Stamping</li>
              <li>Drop-Shipping Export Palletizing</li>
            </ul>
          </div>

          <div>
            <div className="text-white font-semibold uppercase tracking-wider mb-3">Direct Workshop & Contact</div>
            <p className="text-[11px] leading-relaxed">
              No. 14 Jinpen Middle Road, Zhongluotan Town, Baiyun District, Guangzhou, Guangdong, China.
            </p>
            <div className="mt-2 text-[11px] text-white">
              WhatsApp: <a href="https://wa.me/8613420913206" target="_blank" rel="noreferrer" className="text-[#C5A059] underline hover:text-[#DFC48D]">+86 13420913206 (Luke Wu)</a>
            </div>
            <div className="mt-1 text-[11px] text-white">
              Email: <a href="mailto:13420913206@163.com" className="text-[#C5A059] underline hover:text-[#DFC48D]">13420913206@163.com</a>
            </div>
            <div className="mt-2 text-[11px] text-[#A3B1C2]">
              Export Ports: Guangzhou / Shenzhen (FOB)
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-[#C5A059]/10 flex flex-col sm:flex-row justify-between items-center text-[10px] text-[#A3B1C2]">
          <div>© {new Date().getFullYear()} Guangzhou Fengyuan Craft Products Co., Ltd. All rights reserved.</div>
          <div className="mt-2 sm:mt-0 space-x-4">
            <span>Confidential OEM Protection Guaranteed</span>
            <span>•</span>
            <span>Worldwide Express Sampling</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
