/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        obsidian: '#0D1117',
        'obsidian-card': '#141A23',
        'obsidian-surface': '#1C2430',
        'forest-velvet': '#0A2118',
        champagne: '#C5A059',
        'champagne-light': '#DFC48D',
        'champagne-dark': '#9A7B39',
        ivory: '#F8F9FA',
        'ivory-muted': '#A3B1C2',
        hairline: 'rgba(197, 160, 89, 0.2)',
      },
      fontFamily: {
        serif: ['"Bodoni Moda"', 'serif'],
        sans: ['Archivo', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
    },
  },
  plugins: [],
}
